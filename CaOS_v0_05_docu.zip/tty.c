


tty_open
tty_release
tty_read
tty_write
tty_ioctl









