#include "inline_asm.h"


void oops(unsigned int data);
