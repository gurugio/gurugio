/********************************************************************
 * PROJECT : 
 * DESCRIPTION : refer to http://www.nongnu.org/lkdp/files.html
 * MADE BY : 
 * FILE NAME : 
 * WARNING :
 *******************************************************************/


#include "buddy.h"


#define total_pages (1024)
#define PAGE_SIZE 4096



/**************************************************************** 
 * NAME : init_zone
 * SYNOPSIS : initialize a zone.
 *            store information about the zone, 
 *            name of the zone, 
 *            number of free pages, 
 *            index of first pages belong to the zone.
 *            Because there can be several zone, 
 *            init_zone function must have argument as attribute of the zone
 * EXTERNAL EFFECTS : mem_map
 * ARGUMENTS : zone pointer of zone to be initialized
 *             name string pointer
 *             int pages_num number of free pages 
 *             page_index index of first pages belong to the zone
 * RETURNS : N/A
 * ERRNO : N/A
 ****************************************************************/
void init_zone(zone_t *zone, char *name, unsigned int pages_num, unsigned int page_index)
{
		int i;
		
		zone->name = name;
		zone->size = pages_num;
		zone->free_pages = pages_num;
		/* Mminimum number of free pages, always belong to the zone ,
		 * is 1% of initialized number of free pages */
		zone->pages_min = (unsigned int)(pages_num / 100);
		
		/* init all free lists */
		for (i = 0; i < 10; i++)
				INIT_LIST_HEAD(&((zone->free_area[i]).free_list));

		/* init all bitmap indecate the status of buddy block */
		(zone->free_area[0]).map = bitmap_0;
		(zone->free_area[1]).map = bitmap_1;
		(zone->free_area[2]).map = bitmap_2;
		(zone->free_area[3]).map = bitmap_3;
		(zone->free_area[4]).map = bitmap_4;
		(zone->free_area[5]).map = bitmap_5;
		(zone->free_area[6]).map = bitmap_6;
		(zone->free_area[7]).map = bitmap_7;
		(zone->free_area[8]).map = bitmap_8;
		(zone->free_area[9]).map = bitmap_9;

		/* zone_mem_map indicates the page descriptor of the first page
		 * in the pages which belong to the zone. */
		zone->zone_mem_map = mem_map+page_index;
		/* physical address of the first page */
		zone->zone_start_paddr = page_index * PAGE_SIZE;
		/* index of the first page */
		zone->zone_start_mapnr = page_index;

}


/**************************************************************** 
 * NAME : init_mem_map
 * SYNOPSIS : initalize page descriptor table.
 *            There is only one page descriptor table,
 *            and are several zones. 
 *            Therefore every zones share one page descriptor table
 *            and kernel must invoke this function several times.
 *            there can be several zones. 
 *            Therefore i give argument zone.
 * EXTERNAL EFFECTS : mem_map
 * ARGUMENTS : zone the zone which pages belong to.
 *             start first index of the pages
 *             size number of the pages belong to the zone
 * RETURNS : N/A
 * ERRNO : N/A
 ****************************************************************/
void init_mem_map(zone_t *zone, unsigned int start, unsigned int size)
{
		page_t *p;

		/* intialize a certain part of the page descriptor table
		 * which describe the status of pages belong to the zone. */
		for (p = mem_map+start; p < mem_map + size; p++) {
				p->count = 0;
				INIT_LIST_HEAD(&(p->list));
				p->zone = zone;
				p->flag = 0x0;
		}
		
}


/**************************************************************** 
 * NAME : print_free_list
 * SYNOPSIS : test
 * EXTERNAL EFFECTS : 
 * ARGUMENTS : 
 * RETURNS : 
 * ERRNO : 
 ****************************************************************/
void print_free_list(zone_t *zone)
{
		unsigned int order = 0;
		free_area_t *area;
		page_t *page;
		list_head *head, *curr;

		area = &(zone->free_area[order]);

		printf("\n---------free_list------------\n");
		do {
				/* 
				 * print all free list in the each order 
				 */
				head = &(area->free_list);
				curr = head->next;

				printf("free_list[%d] : ", order);
				/*
				 * print all entry in the free list
				 */
				while (curr != head) {
						page = list_entry(curr, page_t, list);
						printf("%d~%d ", page - zone->zone_mem_map, (int)(page-zone->zone_mem_map)+((1<<order)-1));
						curr = curr->next;
				}
				printf("\n");
				
				area++;
				order++;
		} while (order < MAX_ORDER);
		printf("------------------------------\n\n");

}


/**************************************************************** 
 * NAME : init_free_list
 * SYNOPSIS : initalize all free list of each order from 0 to 9 in the zone
 *            There can be several zones, 
 *            therefore there can be several free list in the system.
 * EXTERNAL EFFECTS : N/A
 * ARGUMENTS : zone pointer of the zone in which the free list is
 * RETURNS : N/A
 * ERRNO : N/A
 ****************************************************************/
void init_free_list(zone_t *zone)
{
		/* first page in the zone */
		page_t *p = zone->zone_mem_map;
		free_area_t *area = &(zone->free_area[MAX_ORDER-1]);
		/* buddy block size */
		unsigned int size = 1 << (MAX_ORDER-1);
		unsigned int list_count;
		list_head *list;
		/* number of free pages in the zone */
		unsigned int pages_num = zone->free_pages;
		

		/* If the number of total free pages in the zone is 4000,
		 * 4000 is 512*7 + 256 + 128 + 32 = 2^9 * 7 + 2^8 + 2^7 + 2^5.
		 * Therefore there area 7 blocks in 9th area,
		 * 1 block in 9th area, 1 block in 7th block and 
		 * same in 5th area.*/

		/* It cannot count 1 page block but 2^1 ~ 2^9 page block. */
		while (size > 0) { 
				list = &(area->free_list);
				/* How many block can be in the list? 
				 * ex) 4000 pages => 7 * 512 page block => 7 block can be inserted.*/
				list_count = pages_num / size;
				/* compute remained pages */
				pages_num -= (list_count * size);

				/* insert page bloc into free list of each area */
				for (; list_count > 0; list_count--) {
						__list_add(&(p->list), list->prev, list);
						p += size;
				}
		
				/* next block. (512 -> 256 -> ...) */
				size >>= 1;
				area--; /* down to below area */
		}

}


/**************************************************************** 
 * NAME : set_page_count
 * SYNOPSIS : set counter of each page 
 * EXTERNAL EFFECTS : N/A
 * ARGUMENTS : page pointer of first page being initialized.
 *             count count to be set
 *             order page bloc order (0~9 => 1~512 size)
 * RETURNS : N/A
 * ERRNO : N/A
 ****************************************************************/
void set_page_count(page_t *page, int count, unsigned int order)
{
		unsigned int i;
		
		for (i = 0; i < (1 << order); i++)
				(page++)->count = count;
}


/**************************************************************** 
 * NAME : expand
 * SYNOPSIS : This fundtion process free list and bitmap of each area.
 *            If user request order 3 and find free block at order 8,
 *            It divide order 8 block into two order 7 blocks,
 *            and ont order 7 block is inserted at order 7 free list,
 *            and it divide order 7 block into two order 6 blocks,
 *            and repeat this process.
 *            Last two order 3 blocks remain, one block is return to user,
 *            and another block is inserted at order 3 free list.
 *            This function process this sequence.
 *            It receive high order which is big block to be divided
 *            and low order which is requested block size as argument,
 *            and divide big block until the block become requested size.
 *            And it inserted remained block at free list of each order.
 * EXTERNAL EFFECTS : N/A
 * ARGUMENTS : zone pointer of zone have free blocks.
 *             page first page to be divided
 *             index index of first page to be divided
 *             low_order requested order by user
 *             high_order order of page block to start being divided
 *             area area which high order block belong to
 * RETURNS : pointer of page descriptor
 * ERRNO : N/A
 ****************************************************************/
page_t *expand(zone_t *zone, page_t *page, unsigned int index, \
				unsigned int low_order, unsigned int high_order, free_area_t *area)
{
		/* size of current page block */
		unsigned int size = 1 << high_order;

		/* from high order to low order */
		while (high_order > low_order) {
				/* decrease order */
				area--;
				high_order--;
				size >>= 1;

				/* insert page block into free list */
				//list_add(&(page->list), &(area->free_list));
				list_add(&((page+size)->list), &(area->free_list));

				/* If the bit in the area's bitmap is 1,
				 * it means that one buddy block is completly free and
				 * another is partly or completly used.
				 * So if it allocate page from its pair,
				 * one buddy is used and another is complely free.
				 * Therefore its bit must be 1.
				 * If its bit is 1 and allocate page from its buddy block,
				 * both of the buddy is used, so the bit must be 0.
				 * Finally if the page block is allocated,
				 * we must always toggle the bit which indicate the buddy pair */
				
				/* toggle bit indicate the block buddy */
				//MARK_USED(index, high_order, area);
				__change_bit(index >> (1+(high_order)), area->map);

				//index += size;
				//page += size;
		}
		return page;  /* return pointer of the first page's descriptor */
}


/**************************************************************** 
 * NAME : rmqueue
 * SYNOPSIS : This function is invoked by alloc_pages().
 *            First it find free page block by searching all free list.
 *            If there is a free block in high order area than requested order,
 *            it remove the block from free list 
 *            and invoke expand to divide the block and return the page pointer.
 * EXTERNAL EFFECTS : N/A
 * ARGUMENTS : zone pointer of zone
 *             order requested order
 * RETURNS : page pointer of first allocated page
 * ERRNO : NULL cannot find any block and fail to allocate
 ****************************************************************/
page_t *rmqueue(zone_t *zone, unsigned int order)
{
		free_area_t *area;
		unsigned int curr_order = order;
		page_t *page;
		list_head *head, *curr;
		unsigned int index;

		area = &(zone->free_area[order]);

		/* search all free list and find free page block bigger than request size */
		do {
				/* head => header of free list 
				 * curr => first entry of free list */
				head = &(area->free_list);
				curr = head->next;

				/* It there is any free block in the free list,
				 * first entry in the free list will be not header. */
				if (curr != head) {
						/* get pointer of page descriptor 
						 * which describe the first page of free block */
						page = list_entry(curr, page_t, list);

						/* remove the block from free list */
						list_del(curr);

						/* get the page index */
						index = page - zone->zone_mem_map;

						/*
						 * If the order is maximum order, 
						 * it does not toggle the bit.
						 * Because the bitmap indicate the status of buddy 
						 * and we can check the buddy pair can be merged into big one,
						 * the highest order bit do have not to set to avoid being merged.
						 * If order is maximum order and the bit is 1,
						 * free_pages function may try to merge the block 
						 * the biggest free block is merged again repeatly. 
						 */

						/* Only the case that the order is not maximum order,
						 * it toggle the bit                                 */
						if (curr_order != MAX_ORDER-1)
								//MARK_USED(index, curr_order, area);
								__change_bit(index >> (1+curr_order), area->map);

						/* subtract amount of allocated pages */
						zone->free_pages -= (1UL << order);
						printf("\n## FIND pages at order(%d)\n", curr_order);
						
						/* 
						 * divide big size block and return requested size block
						 */
						page = expand(zone, page, index, order, curr_order, area);

						/* count of all allocated page is 1 */
						set_page_count(page, 1, order);
						printf("\n## ALLOCATED page index : (%d)\n", page-zone->zone_mem_map);
						return page;
				}
				/* next order */
				curr_order++;
				area++;
		/* find free block until maximum size block */
		} while (curr_order < MAX_ORDER);

		/* error : cannot find any block */
		return NULL;
}

/**************************************************************** 
 * NAME : alloc_page
 * SYNOPSIS : test the zone that it has enough free pages
 *            and if true, invoke rmqueue() to process free list & botmap
 *            or return NULL.
 * EXTERNAL EFFECTS : NULL
 * ARGUMENTS : zone pointer of zone to be tested
 *             gfp_mask flag
 *             order (requested page size = 2^order = 1 << order)
 * RETURNS : page pointer of first allocated page
 * ERRNO : NULL cannot find any block and fail to allocate
 ****************************************************************/
page_t *alloc_pages(zone_t *zone, unsigned int gfp_mask, unsigned int order)
{
		unsigned long min;
		page_t *page;

		/* minimum number of pages the zone must have */
		min = (1UL << order) + zone->pages_min;
	
		printf("\n## REQUEST pages order(%d)\n", order);

		/*
		 * Now check the zone has enough free pages
		 */
		if (zone->free_pages > min+zone->pages_min) {
				printf("## DO alloc_page from (%s)\n", zone->name);
				page = rmqueue(zone, order);
				if (page != NULL)
						return page;
		}

		/* 
		 * If some flag is set, decrease minimum number of pages,
		 * and try allocating again
		 */
		if ( (gfp_mask & __GFP_WAIT) == 1) {
				/* minimum = requested size + (pages_min/2) */
				min -= (zone->pages_min>>2);
				if (zone->free_pages > min) {
						printf("\n## DO alloc_page from (%s)\n", zone->name);
						page = rmqueue(zone, order);
						if (page != NULL)
								return page;
				}
		}

		printf("\n## FAIL to allocate (%d) pages\n", (1 << order));
		return NULL;
}


/* 
 * Here is comment written in kernel code
 * linux-2.4.19/mm/page_alloc.c
 */

/*
 * Freeing function for a buddy system allocator.
 *
 * The concept of a buddy system is to maintain direct-mapped table
 * (containing bit values) for memory blocks of various "orders".
 * The bottom level table contains the map for the smallest allocatable
 * units of memory (here, pages), and each level above it describes
 * pairs of units from the levels below, hence, "buddies".
 * At a high level, all that happens here is marking the table entry
 * at the bottom level available, and propagating the changes upward
 * as necessary, plus some accounting needed to play nicely with other
 * parts of the VM system.
 * At each level, we keep one bit for each pair of blocks, which
 * is set to 1 iff only one of the pair is allocated.  So when we
 * are allocating or freeing one, we can derive the state of the
 * other.  That is, if we allocate a small block, and both were   
 * free, the remainder of the region must be split into blocks.   
 * If a block is freed, and its buddy is also free, then this
 * triggers coalescing into a block of larger size.            
 *
 * -- wli
 */


/**************************************************************** 
 * NAME : free_pages
 * SYNOPSIS : it free pages.
 *            Pages can be freed in blocks of specific orders(0~9)
 *            only when they are block aligned, ie. if you are
 *            trying to free a 16 page block, it needs to be on
 *            a 16 page boundary.
 * EXTERNAL EFFECTS : N/A
 * ARGUMENTS : page pointer first page in the freed pages block.
 *             order order of freed pages block.
 * RETURNS : N/A
 * ERRNO : N/A
 ****************************************************************/
void free_pages(page_t *page, unsigned int order)
{
		unsigned int index, page_index, mask;
		free_area_t *area;
		page_t *base;
		zone_t *zone;
		page_t *buddy1, *buddy2;


		/*    -x = ~x + 1 
		 * => ~x = -x - 1
		 * Therefore (~0) << order = (-0 - 1) << order = -(1 << order)
		 * mask = -(1 << order) => negative size of freed pages
		 */
		mask = (~0UL) << order;
		zone = page->zone;  /* zone the page is in */
		base = zone->zone_mem_map;  /* first page in the zone */
		page_index = page - base;   /* index of page at the zone */
		
		/* ex) order -> 3, page_index = 24
		 *     24 & ~3 = 11000 & 11100 = 0
		 * check the page block is aligned by order */
		if (page_index & ~mask) {
				printf("\n## align error\n");
				return;
		}
		
		printf("\n## FREE page (%d~%d)\n", page - zone->zone_mem_map, page - zone->zone_mem_map+(1<<order)-1);
		
		/* clear page counter and flag */
		set_page_count(page, 0, order);
		page->flag &= ~((1 << PG_referenced) | (1 << PG_dirty));

		/* bit index in the buddy bitmap */
		index = page_index >> (1 + order);
		/* area to start merging */
		area = zone->free_area + order;
		
		/* -mask = (1 << order)
		 * increase number of free pages in the zone */
		zone->free_pages -= mask;

		/* 
		 * mask = -(1 << order)
		 * So if the order of mask is (MAX_ORDER-1)
		 * mask = -(1<< (MAX_ORDER - 1))
		 * so mask + (1 << (MAX_ORDER-1)) is 0
		 * Therefore this loop until the order increase to maximum order.
		 */
		while (mask + (1 << (MAX_ORDER-1))) {
				/* 
				 * If the bit is 1, it means that one buddy block is completly free
				 * and another buddy is now freed. So the buddy pair can be merged bigger one 
				 * But if the bit is 0, they cannot be merged.
				 * This check the bit and decide to merge the buddy pair or exit the loop.
				 */
				
				/* If the bit is 1, return 1 and clear the bit.
				 * It the bit is 0, return 0 and set the bit and exit the function. */
				if (__test_and_change_bit(index, (void *)area->map) == 0) {
						printf("end merge\n");
						break;
				}

				/* get the pointer to the first page of buddy of the block of pages being freed.
				 * Now, the block of pages being freed can be either in front of its buddy
				 * or follow its buddy. In other words, to get the pointer to the buddy, we may
				 * have to add the number of pages or subtract them.
				 * ex) freeing page : 5 ,order 0 -> buddy page : 4
				 *     (assume base = 0) 
				 *     buddy1 = 0 + (5 ^ 1) = 0101 ^ 0001 = 4
				 *     buddy2 = 0 + 5 = 5
				 *     On vice versa,
				 *     budd1 = 0 + (4 ^ 1) = 0100 ^ 0001 = 5
				 *     buddy2 = 0 + 4 = 4
				 */
				
				/* Always buddy1 is in free list,
				 * so we must remove buddy1 from free list and merge with buddy2. */
				buddy1 = base + (page_index ^ -mask);
				buddy2 = base + page_index;
				printf("\n## buddy1 : %d, buddy2 : %d => MERGE! \n", buddy1-base, buddy2-base);
				list_del(&(buddy1->list));
				printf("\n## list_del(%d) from order(%d)\n", buddy1-base, area-zone->free_area);
				
				/* go next area to try to merge blocks of higher order. */
				mask <<= 1;  /* increase order */
				area++;      /* next area */
				index >>= 1; /* bitmap index */
				/* 'page_index' always indicate the first page of the buddy */
				page_index &= mask;
		}

		/* base->page_index == buddy1 */
		/* If order is 9, variable buddy1 is not computed,
		 * so base->page_index is used */
		list_add(&(base + page_index)->list, &(area->free_list));
		printf("\n## list_add(%d) from order(%d)\n", (base+page_index)-base, area-zone->free_area);

}
				

/**************************************************************** 
 * very poor test function 
 ****************************************************************/
void print_bitmap(void)
{
		int i, j;
		free_area_t *area = zone.free_area;
		unsigned char *bitmap;
		
		for (j = 0; j < 5; j++) {
				bitmap = area->map;
				printf("ORDER(%d) : ", j);
				for (i = 0; i < 30; i++)
						printf("%2x ", bitmap[i]);
				printf("\n");
				area++;
		}


		for (; j < MAX_ORDER; j++) {
				bitmap = area->map;
				printf("ORDER(%d) : ", j);
				for (i = 0; i < 2; i++)
						printf("%2x ", bitmap[i]);
				printf("\n");
				area++;
		}
		
		printf("##  NUMBER of free pages : %d\n", (int)zone.free_pages);
}		
		

/* TO DO LIST :
 * make busy pages list
 */

int main(void)
{

		int i;
		int order[10];
		page_t *page[10];


		mem_map = malloc(total_pages*sizeof(page_t));
		
		init_mem_map(&zone, 0, total_pages);
		init_zone(&zone, zone_name, total_pages, 0);
		init_free_list(&zone);
		
		srand((unsigned)time(NULL));
		print_free_list(&zone);

		

		/*
		for (i = 0; i < 10; i++) {
				order[i] = (rand() % 7) + 3;
				printf("order[%d] = %d\n", i, order[i]);
		}
		*/
		order[0] = 6;
		order[1] = 8;
		order[2] = 4;
		order[3] = 6;
		order[4] = 6;
		order[5] = 5;
		order[6] = 7;
		order[7] = 5;
		order[8] = 6;
		order[9] = 8;
		
		for (i = 0; i < 10; i++) {
				printf("\n\n========= %dth allocation ============\n\n", i+1);
				page[i] = alloc_pages(&zone, 0, order[i]);
				print_free_list(&zone);
				print_bitmap();
		}


		printf("\n\n================ free page1 =================\n\n");
		free_pages(page[1], order[1]);
		print_free_list(&zone);
		print_bitmap();

		printf("\n\n================ free page4 =================\n\n");
		free_pages(page[4], order[4]);
		print_free_list(&zone);
		print_bitmap();
		
		
		printf("\n\n================ free page6 =================\n\n");
		free_pages(page[6], order[6]);
		print_free_list(&zone);
		print_bitmap();
		
		printf("\n\n================ free page8 =================\n\n");
		free_pages(page[8], order[8]);
		print_free_list(&zone);
		print_bitmap();
		
		printf("\n\n================ free page2 =================\n\n");
		free_pages(page[2], order[2]);
		print_free_list(&zone);
		print_bitmap();
		
		printf("\n\n================ free page3 =================\n\n");
		free_pages(page[3], order[3]);
		print_free_list(&zone);
		print_bitmap();
		
		printf("\n\n================ free page5 =================\n\n");
		free_pages(page[5], order[5]);
		print_free_list(&zone);
		print_bitmap();
		
		printf("\n\n================ free page7 =================\n\n");
		free_pages(page[7], order[7]);
		print_free_list(&zone);
		print_bitmap();
		
		printf("\n\n================ free page9 =================\n\n");
		free_pages(page[9], order[9]);
		print_free_list(&zone);
		print_bitmap();
		
		printf("\n\n================ free page10 =================\n\n");
		free_pages(page[0], order[0]);
		print_free_list(&zone);
		print_bitmap();
		
		
		return 0;
}




