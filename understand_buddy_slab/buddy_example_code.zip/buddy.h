#include <stdio.h>
#include <stdlib.h>
#include <time.h>



#include "list.h"


/* gfp_mask for test */
#define __GFP_WAIT 0x1

#define MAX_ORDER 10 

/* flags for page descriptor */
#define PG_referenced		 2
#define PG_uptodate		 3
#define PG_dirty		 4
#define PG_unused		 5
#define PG_slab			 8
#define PG_skip			10
/* for kernel code, BIOS, hardware..cannot be freed*/
#define PG_reserved		14




typedef unsigned long ULONG;
typedef unsigned char UCHAR;


/* 
 * Linux uses lists of 1,2,4,8,16,32,64,128,256,512 page blocks.
 * To manage these lists  and implement the buddy system 
 * it uses the this struct 
 */
typedef struct free_area {
		/* 
		 * Its a double linked list of free page blocks of a certain size.
		 * It points to the first and last page blocks, while the list member
		 * of page_t is used to link up the pages in between 
		 */
		list_head free_list;
		/* 
		 * Also known as the buddy bitmap, it is contains information
		 * about the availability of a buddy. Its size is calculated using
		 * the firmula:
		 *   ((number of pages) - 1 >> (order + 4)) + 1 bytes
		 * Each bit represents two adjacent blocks of the same size.
		 * Its value is 0 if both the blocks are either prtially or
		 * fully used (busy) of completely free. It is 1 if exactly one
		 * of the blocks is completely free and the other is (partially or fully) used 
		 */
		UCHAR *map;
} free_area_t;


/* 
 * Also each physical page of memory (or page frame) has an associated
 * page_t which contains all the information needed to manage them
 */
struct page_descriptor {
		/*
		 * This is used to point to the next page in any list
		 */
		list_head list;
		/* 
		 * Number of references to this page (usage count)
		 */
		int count;
		/*
		 * attributes of the page
		 */
		UCHAR flag;
		/*
		 * zone the page is included in
		 */
		struct zone_struct *zone;
};


/* Physical memory has been divided into different zones 
 * to differentiate between intended uses, and are generally used
 * to model different characteristics of the memory.
 * But CaOS has only one zone and all phisical memory is 
 * in same zone. The name of zone is 'CaOS'. */
struct zone_struct {
		char *name;        /* name of zone */
		ULONG size;        /* number of total pages the zone has */
		ULONG free_pages;  /* number of free pages of the zone */
		ULONG pages_min;   /* minimum number of free page must be in zone */
		free_area_t free_area[10]; /* free list and bitmap for buddy algorithm */
		/* page descriptor table of the pages which is in the zone */
		struct page_descriptor *zone_mem_map;
		ULONG zone_start_paddr;  /* start phisical address */
		ULONG zone_start_mapnr;  /* the first page descriptor index of the zone */
};


typedef struct page_descriptor page_t;
typedef struct zone_struct zone_t;


//#define MARK_USED(index, order, area) \
//				__change_bit((index) >> (1+(order)), (area)->map);

		
/* These macros are written by inline assembly code in Linux kernel,
 * but I write this macro with C lanuage for portability */

/*
 * toggle bit
 * index : page descriptor index
 * order : order of bitmap
 * area : 
 */
void __change_bit(unsigned int index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		/* toggle */
		if ( (*p & (1 << bit)) != 0)  /* if 1 */
				*p &= ~(1 << bit);        /* clear */
		else                          /* if 0 */
				*p |= (1 << bit);         /* set */
}

/* If the bit is 1, return 1 and clear
 * else the bit is 0, return 0 and set */
unsigned char __test_and_change_bit(unsigned index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		/* bit is 1 */
		if ( (*p & (1 << bit)) != 0) {
				*p &= ~(1 << bit);  /* clear */
				return 1;
		/* bit is 0 */
		} else {
				*p |= (1 << bit);  /* set */
				return 0;
		}
}

unsigned char  __get_bit(unsigned int index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		return *p & (1 << bit);
}


void __set_bit(unsigned int index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		*p |= (1 << bit);
}


void __clear_bit(unsigned int index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		*p &= ~(1 << bit);
}


/*
 * pointer to page descriptor table
 */
page_t *mem_map;

/*
 * CaOS zone
 */
zone_t zone;


/* 
 * bitmap from 0 to 9 order 
 */
UCHAR bitmap_0[1024];
UCHAR bitmap_1[512];
UCHAR bitmap_2[256];
UCHAR bitmap_3[128];
UCHAR bitmap_4[64];
UCHAR bitmap_5[32];
UCHAR bitmap_6[16];
UCHAR bitmap_7[8];
UCHAR bitmap_8[4];
UCHAR bitmap_9[2];

char zone_name[] = "CaOS";




page_t *expand(zone_t *, page_t *, unsigned int, \
				unsigned int, unsigned int, free_area_t *);
void init_zone(zone_t *, char *, unsigned int, unsigned int);
void init_mem_map(zone_t *, unsigned int, unsigned int);
void print_free_list(zone_t *);
void init_free_list(zone_t *);
void set_page_count(page_t *, int, unsigned int);
page_t *rmqueue(zone_t *, unsigned int);
