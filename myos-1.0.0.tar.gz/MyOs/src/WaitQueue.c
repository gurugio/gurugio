/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <WaitQueue.h>
#include <Process.h>
#include <Schedule.h>
#include <Types.h>


void add_wait_queue( WaitQueue *queue, ProcessTable *waitProcess )
{
	WaitQueue *temp;


	temp	= (WaitQueue *)kalloc( sizeof(WaitQueue) );
	if( temp == NULL )
		return;

	temp->waitProcess	= waitProcess;
	
	waitProcess->status	= PROCESS_INTERRUPTIBLE;

	INSERT_WAIT_QUEUE( queue, temp );
}

void del_wait_queue( WaitQueue *queue, ProcessTable *process )
{
	WaitQueue *temp;
	List *index;

	
	SEARCH_WAIT_QUEUE( queue, index )
	{
		temp	= WAIT_QUEUE_ENTRY( index );
		
		if( temp->waitProcess == process )
		{
			temp->waitProcess->status	= PROCESS_RUNNING;

			DELETE_WAIT_QUEUE( queue, temp );

			kfree( temp );
			
			break;
		}
	}
}

void del_wait_queue_by_seq( WaitQueue *queue, unsigned int flags )
{
	WaitQueue *temp;
	List *index;

	
	SEARCH_WAIT_QUEUE( queue, index )
	{
		temp	= WAIT_QUEUE_ENTRY( index );

		temp->waitProcess->status	= PROCESS_RUNNING;

		DELETE_WAIT_QUEUE( queue, temp );

		kfree( temp );
		
		if( flags & WAKE_UP_ONE )
			break;
	}
}
