/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Stdarg.h>
#include <Sys.h>


void m_print( const char *field, ... )
{
	static const char hex[16] = "0123456789abcdef";
	
	va_list	arg;

	char	buffer[80];
	char	*des, *src;
	
	int	i, count;
	char *s, c;


	va_start( arg, field );

	des	= buffer;
	src	= (char *)field;

	while( *src != '\0' )
	{
		if( *src == '%' && src++ )
		{
			switch( *src++ )
			{
				case	'd':
					i	= va_arg( arg, int );
					count	= 1000000000;
					for( ; count>0 && i/count == 0; count /= 10 );
					while( i >= 0 && count > 0 )
					{
						*des++	= (i/count) + '0';
						i		= i % count;
						count	/= 10;
					}
					break;
					
				case	'x':
					*des++	= '0';
					*des++	= 'x';
					i	= va_arg( arg, int );
					#if 1
					for( count = 28; count >= 0; count -= 4 )
						if( (i >> count) & 0xf )
							break;
					if( count <= 0 )
						*des++	= '0';
					#endif
					for( count = 28; count >= 0; count -= 4)
						*des++	= hex[ (i >> count) & 0xf ];
					break;

				case	's':
					s	= va_arg( arg, char * );
					while( *s != '\0' )
						*des++	= *s++;
					break;

				case	'c':
					c	= (char)va_arg( arg, int );
					*des++	= c;
					break;
			}
		}
		else
			*des++	= *src++;
	}

	*des	= '\0';

	m_write( 1, buffer, m_strlen(buffer) );
}
