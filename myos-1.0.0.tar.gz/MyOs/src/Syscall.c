/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Syscall.h>
#include <Types.h>
#include <Process.h>
#include <Timer.h>
#include <Schedule.h>


extern int	do_exit( void );
extern int	do_fork( RegsInStack * );


static int sys_no_call( void )
{
	return 0;
}

static int sys_exit( void )
{
	do_exit();

	return 0;
}

static int sys_fork( RegsInStack regs )
{
	return do_fork( &regs );
}

static int sys_pause( void )
{
	ProcessTable	*p = current;

	p->status	= PROCESS_INTERRUPTIBLE;

	schedule();

	return 0;
}

static int sys_open( const char *name, int flags )
{
	ProcessTable	*p = current;
	DeviceTable	*device;
	
	int	i;
	

	if( name == NULL )
		return -1;

	device	= search_device_table( name );
	if( device == NULL )
		return -1;

	for( i = 0; i < MAX_DEVICE_OPEN; i++ )
	{
		if( p->device[i] == NULL )
		{
			p->device[i]	= (Device *)kalloc( sizeof(Device) );
			
			m_strcpy( p->device[i]->name, name );

			p->device[i]->op	= device->op;

			p->device[i]->offset	= 0;

			if( p->device[i]->op->open )
				p->device[i]->op->open();
	
			return i;
		}
	}

	return -1;
}
	
static int sys_close( int des )
{
	ProcessTable	*p = current;


	if( des >= MAX_DEVICE_OPEN || p->device[des] == NULL )
		return -1;

	if( p->device[des]->op->close )
		p->device[des]->op->close();

	kfree( p->device[des] );

	p->device[des]	= NULL;

	return 0;
}

static int sys_read( int des, char *buffer, int size )
{
	ProcessTable	*p = current;


	if( des >= MAX_DEVICE_OPEN || p->device[des] == NULL || buffer == NULL )
		return -1;

	if( p->device[des]->op->read != NULL )
		return p->device[des]->op->read( buffer, size );

	return -1;
}

static int sys_write( int des, const char *buffer, int size )
{
	ProcessTable	*p = current;


	if( des >= MAX_DEVICE_OPEN || p->device[des] == NULL || buffer == NULL )
		return -1;

	if( p->device[des]->op->write != NULL )
		return p->device[des]->op->write( buffer, size );

	return -1;
}

static int sys_seek( int des, int offset, int base )
{	
	ProcessTable	*p = current;


	if( des >= MAX_DEVICE_OPEN || p->device[des] == NULL )
		return -1;

	if( p->device[des]->op->seek != NULL )
		return p->device[des]->op->seek( offset, base );

	return -1;
}

static int sys_ioctl( int des, int command )
{
	ProcessTable	*p = current;

	
	if( des >= MAX_DEVICE_OPEN || p->device[des] == NULL )
		return -1;

	if( p->device[des]->op->ioctl != NULL )
		return p->device[des]->op->ioctl( command );

	return -1;
}

static int sys_sleep( int sec )
{
	ProcessTable	*p = current;


	p->sleep	= tick + HZ_SECOND * sec;

	p->status	= PROCESS_INTERRUPTIBLE;

	scheduling	= 1;

	return 0;
}

static int sys_usleep( int usec )
{
	ProcessTable	*p = current;


	p->sleep	= tick + HZ_SECOND / (1000000 / usec);

	p->status	= PROCESS_INTERRUPTIBLE;

	scheduling	= 1;

	return 0;
}

static int sys_priority_up( int priority )
{
	current->priority	= priority;

	return 0;
}

static int sys_mount( int inode )
{
	ProcessTable	*p = current;

	p->root	= get_directory( inode );
	p->pwd	= p->root;
	
	return 0;
}

	
typedef int (*SyscallHandler)( void );

#define	SYSCALL_HANDLER(func)		((SyscallHandler)func)

/* syscall handler table... */
SyscallHandler	syscallHandler[] = {
	SYSCALL_HANDLER(sys_no_call),
	SYSCALL_HANDLER(sys_exit),
	SYSCALL_HANDLER(sys_fork),
	SYSCALL_HANDLER(sys_pause),
	SYSCALL_HANDLER(sys_open),
	SYSCALL_HANDLER(sys_close),
	SYSCALL_HANDLER(sys_read),
	SYSCALL_HANDLER(sys_write),
	SYSCALL_HANDLER(sys_seek),
	SYSCALL_HANDLER(sys_ioctl),
	SYSCALL_HANDLER(sys_sleep),
	SYSCALL_HANDLER(sys_usleep),
	SYSCALL_HANDLER(sys_priority_up),
	SYSCALL_HANDLER(sys_mount)
};

unsigned int	howManySyscall = sizeof(syscallHandler)/sizeof(SyscallHandler);
