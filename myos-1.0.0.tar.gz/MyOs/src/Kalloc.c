/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Alloc.h>
#include <Kalloc.h>


/* kernel heap ���� ����� ������ �ӽ÷� �����صд�...not good! */
static unsigned int	kernelHeapBase	= (unsigned int)0xc0200000;
static unsigned int	kernelHeapLimit	= (unsigned int)0x200000;


static HeapArea	kernelHeap;


void init_kernel_heap( void )
{
	create_heap_area( &kernelHeap, kernelHeapBase, kernelHeapLimit );
}

void *kalloc( unsigned int size )
{
	return (void *)alloc( &kernelHeap, size );
}

int kfree( void *block )
{
	return free( &kernelHeap, block );
}
