/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <String.h>
#include <Types.h>


#define	is_digit(src)	(src >= '0' && src <= '9')
#define	is_hex(src)		is_digit(src) || (src >= 'a' && src <= 'f')


int m_atoi( char *src )
{
	int	i =0, mul = 10;


	if( src == NULL )
		return -1;

	if( *src == '0' && *(src+1) == 'x' )
	{
		mul	= 16;
		src	+= 2;
	}
	
	for( ; is_hex(*src); src++ )
		i	= i*mul + ( *src > '9' ? *src - 'a' + 10 : *src - '0' );

	return i;
}

int m_strlen( char *des )
{
	int	i;


	if( des == NULL )
		return -1;

	for( i = 0; *des != '\0'; des++, i++ );

	return i;
}

int m_strcpy( char *des, const char *src )
{
	if( des == NULL || src == NULL )
		return -1;
	
	for( ; *src != '\0'; src++, des++ )
		*des	= *src;

	return 0;
}

int m_strncpy( char *des, const char *src, int num )
{
	int	i;

	
	if( des == NULL || src == NULL )
		return -1;

	for( i = 0; *src != '\0' && i < num; src++, des++, i++ )
		*des	= *src;

	*des	= '\0';
	
	return i;
}
	
int m_strcat( char *des, const char *src )
{
	if( des == NULL || src == NULL )
		return -1;

	for( ; *des != '\0'; des++ );

	for( ; *src != '\0'; src++, des++ )
		*des	= *src;

	return 0;
}

int m_strcmp( char *des, const char *src )
{
	if( des == NULL || src == NULL )
		return -1;

	for( ; *src != '\0'; src++, des++ )
		if( *src != *des )
			return 1;

	return 0;
}

int m_strncmp( char *des, const char *src, int num )
{
	if( des == NULL || src == NULL )
		return -1;

	for( ; *src != '\0' && num > 0; src++, des++, num-- )
		if( *src != *des )
			return 1;

	return 0;
}
		
	
