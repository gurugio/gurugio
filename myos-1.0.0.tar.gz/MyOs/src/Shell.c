/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Types.h>
#include <Sys.h>
#include <Screen.h>
#include <Keyboard.h>
#include <Process.h>
#include <Util.h>
#include <Time.h>
#include <Ide.h>
#include <Ext2.h>


extern int	ball( void );


const char	*message = {
	"Welcome~ to MyOs...\n"
	"This is inhyuk's os...\n"
	"It's free!!!\n"
	"Enjoy your self!\n\n"
	"Press 'help' command!\n\n"
};

const char	*help = {
	"\nCommand		Info\n\n"
	" help		display this help message\n"
	" clear		clear screen\n"
	" process	display process status\n"
	" dump		dump memory( ex. dump 0xc0093000 0xc0093100 )\n"
	" ball		create ball thread\n"
	" color		set text attribute( ex. color 0x3 0x4 )\n"
	" ls			display file list in current directory\n"
	" cd			change directory\n"
	" mount		mount root file system(only ext2 on primary master ide)\n"
	"\n"
};


typedef struct _command		Command;
struct _command
{
	char	name[10];

	void	(*run)( char * );
};


static void	do_help( char * );
static void	do_clear( char * );
static void	do_ball( char * );
static void	do_process( char * );
static void	do_dump( char * );
static void	do_color( char * );
static void	do_ls( char * );
static void	do_cd( char * );
static void	do_mount( char * );

static Command	shellCommand[] = {
	{ "help",		do_help },
	{ "clear",		do_clear },
	{ "process",	do_process },
	{ "dump",		do_dump },
	{ "ball", 		do_ball },
	{ "color",		do_color },
	{ "ls",			do_ls },
	{ "cd", 		do_cd },
	{ "mount",		do_mount }
};

static int	shellCommandLength = sizeof(shellCommand) / sizeof(Command);
	

static void	do_exec( char * );


int shell( void )
{
	char	buffer[80];

	int	len, i;


	set_to_foreground();

	m_write( 1, message, m_strlen(message) );

	while(1)
	{
		m_write( 1, "MyOs) ", 6 );

		len	= m_read( 0, buffer, 80 );

		if( len <= 0 )
			continue;

		for( i = 0; i < shellCommandLength; i++ )
		{
			if( !m_strcmp( buffer, shellCommand[i].name ) )
			{
				shellCommand[i].run( buffer + m_strlen(shellCommand[i].name) );

				break;
			}
		}

		if( i == shellCommandLength )
			do_exec( buffer );
	}
}


static void do_help( char *argv )
{
	m_write( 1, help, m_strlen(help) );
}

static void do_clear( char *argv )
{
	clear_screen();
}

static void do_ball( char *argv )
{
	create_thread( ball );
}

static void do_process( char *argv )
{	
	ProcessTable	*p;

	static const char *status[] = {
		"None           ",
		"Running        ",
		"Interruptible  ",
		"Uninterruptible",
		"Stopped        "
	};

	
	p	= LIST_ENTRY( initProcess->running.next, ProcessTable, running );
	
	while( p != initProcess )
	{
		m_print( "[%x]\t%s\t%x\n", p->pid, status[p->status], p );

		p	= LIST_ENTRY( p->running.next, ProcessTable, running );
	}
}

static void do_dump( char *argv )
{
	int	*from, *to;


	from	= (int *)m_atoi( get_arg(&argv) );
	to		= (int *)m_atoi( get_arg(&argv) );
	
	if( (int)from == -1 || (int)to == -1 )
	{
		m_print( "we need arguments...press 'help' command!\n" );
		
		return;
	}
	
	while( (int)from < (int)to )
	{
		m_print( "%x\t%x\n", from, *from );

		from++;
	}
}

static void do_color( char *argv )
{
	int	back, fore;

	
	back	= m_atoi( get_arg(&argv) );
	fore	= m_atoi( get_arg(&argv) );
	
	if( back < 0 || fore < 0 )
	{
		m_print( "we need arguments...press 'help' command!\n" );
		
		return;
	}

	set_attr( SET_COLOR(back,fore) );
}

static void do_ls( char *argv )
{
	Entry	*entry;
	
	int	offset = 0, line = 1;


	if( current->pwd == NULL )
	{
		m_print( "not mount root file system...!\n" );
		
		return;
	}
	
	while( (entry = get_dir_entry_by_seq( current->pwd, &offset )) != NULL )
	{
		m_print( "%s\t\t", entry->name );
		if( line%5 == 0 )
			m_print( "\n" );
		line++;
	}

	if( (line-1)%5 != 0 )
		m_print( "\n" );
}

static void do_cd( char *argv )
{
	Entry	*entry;

	char	*name;
	
	int	offset = 0;

	
	if( current->pwd == NULL )
	{
		m_print( "not mount root file system...!\n" );

		return;
	}

	name	= get_arg( &argv );
	
	if( !m_strcmp( name, ".." ) && current->pwd == current->root )
		return;
	
	while( (entry = get_dir_entry_by_seq( current->pwd, &offset )) != NULL )
	{
		if( !m_strcmp( entry->name, name ) )
		{
			if( entry->fileType != EXT2_DIR )
				break;

			if( current->pwd != current->root )
				free_directory( current->pwd );
			
			if( entry->inode == ROOT_INODE_NUMBER )
				current->pwd	= current->root;
			else
				current->pwd	= get_directory( entry->inode );
			
			return;
		}
	}
}

static void do_mount( char *argv )
{
	if( current->root != NULL )
	{
		m_print( "root file system mounted already...!\n" );

		return;
	}
	
	init_ext2(0);

	m_mount( ROOT_INODE_NUMBER );
}

static void do_exec( char *argv )
{
	Dentry	*dentry;
	
	char	*fileName;


	fileName	= get_arg( &argv );

	dentry	= get_file( current->pwd, fileName );
	if( dentry == NULL )
	{
		m_print( "file not exist...!\n" );

		return;
	}
	
	get_inode_blocks( (char *)0x80000000, dentry->it );
	
	free_file( dentry );

	asm __volatile__ (
			"call *%0\n"
			:: "m" (0x80000000)
			);
}
