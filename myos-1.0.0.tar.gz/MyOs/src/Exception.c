/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


void handle_divide_error( void )
{
	panic( 1 );
}

void handle_debug( void )
{
	panic( 2 );
}

void handle_nmi( void )
{
	panic( 3 );
}

void handle_breakpoint( void )
{
	panic( 4 );
}

void handle_overflow( void )
{
	panic( 5 );
}

void handle_bound_range_exceeded( void )
{
	panic( 6 );
}

void handle_invalid_opcode( void )
{
	panic( 7 );
}

void handle_nomath( void )
{
	panic( 8 );
}

void handle_doublefault( void )
{
	panic( 9 );
}

void handle_reserved_1( void )
{
	panic( 10 );
}

void handle_invalid_tss( void )
{
	panic( 11 );
}

void handle_segment_not_present( void )
{
	panic( 12 );
}

void handle_stack_segment_fault( void )
{
	panic( 13 );
}

void handle_general_protection( void )
{
	panic( 14 );
}

void handle_reserved_2( void )
{
	panic( 15 );
}

void handle_math_fault( void )
{
	panic( 16 );
}

void handle_alignment_check( void )
{
	panic( 17 );
}

void handle_machine_check( void )
{
	panic( 18 );
}

void handle_floating_point_exception( void )
{
	panic( 19 );
}
