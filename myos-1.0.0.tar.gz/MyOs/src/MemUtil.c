/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Types.h>
#include <MemUtil.h>
#include <Idt.h>


int m_memset( void *des, int c, unsigned int size )
{
	if( des == NULL )
		return -1;
	
	for( ; size > 0; size--, ((char *)des)++ )
		*(char *)des	= (char)c;

	return 0;
}

int m_memcpy( void *des, void *src, unsigned int size )
{
	if( des == NULL || src == NULL )
		return -1;

	for( ; size > 0; size--, ((char *)des)++, ((char *)src)++ )
		*(char *)des	= *(char *)src;

	return 0;
}
