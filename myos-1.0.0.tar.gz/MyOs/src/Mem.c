/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Mem.h>
#include <Kalloc.h>


extern void init_pgd( void );
extern void	init_page_frame( void );
extern void	init_kernel_heap( void );


/* ������ Mbyte �̴�... */
unsigned int	howManyPhysMem = 0;


void init_mem( void )
{
	/* kernel page directory �� �ʱ�ȭ�Ѵ�... */
	init_pgd();

	init_kernel_heap();

	init_page_frame();
}
