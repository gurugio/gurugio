/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Schedule.h>
#include <MemUtil.h>
#include <Process.h>
#include <Irq.h>
#include <Idt.h>
#include <Timer.h>


unsigned int	tick;


static void handle_timer( void )
{
	tick++;

	current->counter--;

	/* current process �� counter ���� 0 ���ϰ� �Ǹ� scheduling �� �ؾ��Ѵ�...
	 */
	if( current->counter <= 0 )
		scheduling	= 1;
}


void init_timer( void )
{
	outb( 0x43, 0x34 );
	outb( 0x40, PIT_LATCH & 0xff );
	outb( 0x40, (PIT_LATCH >> 8) & 0xff );

	register_irq_handler( 0, handle_timer );

	enable_irq( 0 );

	tick	= 0;
}
