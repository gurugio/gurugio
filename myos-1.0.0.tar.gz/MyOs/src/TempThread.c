/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Sys.h>
#include <Screen.h>
#include <Timer.h>
#include <Rand.h>
#include <Process.h>


int thread1( void )
{
	char *p = (char *)0xc00b809c;
	char c = 'A';

	int	i;


	i	= 0;

	while(1)
	{
		m_sleep(2);

		*p	= c;

		*(p+1)	= (char)i++;
		
		if( c == 'Z' )
			c	= 'A';
		else
			c++;

		p	+= 160;
	}
}

int thread2( void )
{
	char *p = (char *)0xc00b809e;
	char c = 'A';
	

	while(1)
	{
		m_sleep(3);
		
		*p	= c;
		*(p+1)	= 0xf0;
			
		if( c == 'Z' )
			c	= 'A';
		else
			c++;

		p	+= 160;
	}
}

int ball( void )
{
	int	i, x, y;


	m_priority_up( 40 );

	for( i = 0; i < 100; i++ )
	{
		x	= m_rand()%80;
		y	= m_rand()%25;

		gotoxy( x, y );

		putch( 'O' );

		m_usleep(100000);

		putch( ' ' );
		
		y++;
	}

	m_exit();
}
