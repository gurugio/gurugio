/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Irq.h>
#include <Types.h>
#include <Device.h>


static const char	*deviceName = "serial";

static int	read_serial( char *, int );
static int	write_serial( const char *, int );

static DeviceOperation serialOperation = {
	NULL,
	NULL,
	read_serial,
	write_serial,
	NULL,
	NULL
};


static int read_serial( char *buffer, int size )
{
	

}

static int write_serial( const char *buffer, int size )
{
	for( ; size > 0; size--, buffer++ )
		outb( 0x3f8, *buffer );

	return size;
}

static void handle_serial( void )
{

}

void init_serial( void )
{
	register_device_table( deviceName, &serialOperation );

	register_irq_handler( 4, handle_serial );

	enable_irq( 4 );

	outb( 0x3fb, 0x80 );
	outb( 0x3f8, 0x17 );
	outb( 0x3f9, 0x0 );
	outb( 0x3fb, 0x03 );
	outb( 0x3fc, 0x0b );
	outb( 0x3f9, 0x0d );
	inb( 0x3f8 );
}
