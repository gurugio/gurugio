/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Device.h>
#include <Kalloc.h>
#include <Types.h>


/* device table list �� �����Ѵ�... */
static DECLARE_LIST_HEAD(deviceTableList);


/* ���ο� device table �� �����ؼ� list �� �߰��Ѵ�...
 *
 * device table �� device name ���� �����Ѵ�...
 */
int register_device_table( const char *name, DeviceOperation *op )
{
	DeviceTable	*new;

	
	new	= (DeviceTable *)kalloc( sizeof(DeviceTable) );
	if( new == NULL )
		return -1;

	m_strcpy( new->name, name );

	new->op	= op;

	INSERT_LIST_TAIL( &deviceTableList, &new->index );

	return 0;
}

int unregister_device_table( const char *name )
{
	DeviceTable *p;
	List	*index;
	

	SEARCH_LIST( &deviceTableList, index )
	{
		p	= LIST_ENTRY( index, DeviceTable, index );

		if( !m_strcmp( name, p->name ) )
		{
			DELETE_LIST( &deviceTableList, &p->index );
			
			kfree( p );

			return 0;
		}
	}

	return -1;
}

DeviceTable *search_device_table( const char *name )
{
	DeviceTable *p;
	List	*index;
	

	SEARCH_LIST( &deviceTableList, index )
	{
		p	= LIST_ENTRY( index, DeviceTable, index );

		if( !m_strcmp( name, p->name ) )
			return p;
	}

	return NULL;
}
