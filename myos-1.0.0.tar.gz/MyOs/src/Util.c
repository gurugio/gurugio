/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Types.h>


char *get_arg( char **arg )
{
	char	*ret;

	
	for( ; **arg == ' ' || **arg == '\t'; (*arg)++ );

	if( **arg == '\n' || **arg == '\0' )
		return NULL;

	ret	= *arg;
	
	for( ; **arg != ' ' && **arg != '\t'
						&& **arg != '\n' && **arg != '\0'; (*arg)++ );

	**arg	= '\0';

	(*arg)++;

	return ret;
}
