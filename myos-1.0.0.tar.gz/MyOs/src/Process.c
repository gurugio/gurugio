/******************************************************************************
 * MyOs	- my special operating system...
 *
 * 
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Types.h>
#include <Process.h>
#include <Page.h>
#include <Gdt.h>
#include <MemUtil.h>
#include <Schedule.h>
#include <Idt.h>
#include <Screen.h>
#include <Syscall.h>
#include <Ext2.h>


/* fork system call ���� ����� return handler �̴�... */
extern void	ret_from_fork( void );

extern unsigned int	*initPgd;

/* initProcess table �� stack ���� ���� page �� �����Ѵ�...not good! */
ProcessStack *initProcessStack = (ProcessStack *)0xc0095000;

/* initTss �� �� �ϳ� �����ϸ� current process �� thread context �� �����Ѵ�...
 */
Tss	*initTss = (Tss *)0xc0096000;

ProcessTable *initProcess;
ProcessTable *foreground;

/* pid �� 0 ����... */
unsigned int currentPid;


void init_process( void )
{
	int	i;


	initProcess	= &initProcessStack->pt;

	initProcess->pid	= INIT_PID;
	
	initProcess->priority	= NORMAL_PRIORITY;
	initProcess->counter	= NORMAL_PRIORITY;

	initProcess->sleep	= 0;
	
	initProcess->thread.eip		= 0;
	initProcess->thread.esp		= 0;
	initProcess->thread.esp0	= (unsigned int)initProcessStack
								+ PROCESS_STACK_SIZE;
	
	initProcess->thread.cr3		= (unsigned int)initPgd;

	/* input device information �� �ʱ�ȭ�Ѵ�... */
	initProcess->inputInfo.mode		= COOKED_MODE;
	initProcess->inputInfo.offset	= 0;
	
	/* screen device information �� �ʱ�ȭ�Ѵ�... */
	init_screen_info( &initProcess->screenInfo );
	
	for( i = 0; i < MAX_DEVICE_OPEN; i++ )
		initProcess->device[i]	= NULL;
	
	INIT_LIST( &initProcess->running );

	initTss->esp0	= initProcess->thread.esp0;
	initTss->ss0	= KERNEL_DATA;

	currentPid	= INIT_PID + 1;
	
	initProcess->status	= PROCESS_RUNNING;

	/* initProcess �� root directory �� NULL �� �����Ѵ�... */
	initProcess->root	= NULL;
	initProcess->pwd	= NULL;
}


void create_thread( int (*func)(void) )
{
	asm __volatile__ (
			"movl %%esp, %%esi\n"
			"movl $2, %%eax\n"
			"int $0x80\n"
			"cmpl %%esp, %%esi\n"
			"je 1f\n"
			"call *%0\n"
			"movl $1, %%eax\n"
			"int $0x80\n"
			"1:\n"
			:: "b" (func)
			);
}


/* current process �� key �Է��� �������ֵ��� foreground process �� �����Ѵ�...
 */
void set_to_foreground( void )
{
	if( foreground != NULL )
		foreground->priority	= NORMAL_PRIORITY;

	foreground	= current;

	foreground->priority	= FOREGROUND_PRIORITY;
}

int do_fork( RegsInStack *regs )
{
	ProcessTable	*parent = current;
	ProcessTable	*child;

	RegsInStack	*childRegs;
	
	int	i;
	
	
	child	= create_process_table();
	
	child->status	= PROCESS_STOPPED;
	child->pid		= currentPid++;

	child->priority	= NORMAL_PRIORITY;
	child->counter	= NORMAL_PRIORITY;

	child->sleep	= 0;

	/* child process �� kernel mode stack �� parent process �� kernel mode
	 * stack �� �����ؼ� user mode �� ��ȯ�� parent process �� ����� ����
	 * �ϰ� �����...
	 */
	childRegs	= (RegsInStack *)((unsigned int)child
				+ (unsigned int)(PROCESS_STACK_SIZE - sizeof(RegsInStack)));
	m_memcpy( childRegs, regs, sizeof(RegsInStack) );
	
	/* child process �� return value �� 0 �̴�... */
	childRegs->eax	= 0;
	
	/* child process �� scheduling �ÿ� ret_from_fork �� �̵��Ѵ�... */
	child->thread.esp0	= (unsigned int)child + PROCESS_STACK_SIZE;
	child->thread.esp	= (unsigned int)childRegs;
	child->thread.eip	= (unsigned int)ret_from_fork;

	child->thread.cr3	= alloc_kernel_cache();
	m_memcpy((void *)child->thread.cr3, (void *)parent->thread.cr3, PAGE_SIZE);
	
	child->inputInfo.mode	= COOKED_MODE;
	child->inputInfo.offset	= 0;

	m_memcpy( &child->screenInfo, &parent->screenInfo, sizeof(ScreenInfo) );
	
	/* parent process �� device descriptor �� �����Ѵ�... */
	for( i = 0; i < MAX_DEVICE_OPEN; i++ )
	{
		if( parent->device[i] == NULL )
			break;
		
		child->device[i]	= (Device *)kalloc( sizeof(Device) );
	
		m_memcpy( child->device[i], parent->device[i], sizeof(Device) );
	}
		
	INSERT_LIST_TAIL( &initProcess->running, &child->running );

	child->status	= PROCESS_RUNNING;

	/* child process �� root directory �� parent process �� root directory
	 * �� �����Ѵ�... */
	if( parent->root != NULL )
		child->root	= get_directory( parent->root->inode );
	child->pwd	= child->root;
	
	return child->pid;
}


void do_exit( void )
{
	ProcessTable	*p = current;
	
			
	DELETE_LIST( &initProcess->running, &p->running );

	p->status	= PROCESS_STOPPED;

	free_kernel_cache( (unsigned int)p->thread.cr3 );
	free_kernel_cache( (unsigned int)p );
	
	if( p->pwd != p->root )
		free_directory( p->pwd );

	free_directory( p->root );

	schedule();
}
