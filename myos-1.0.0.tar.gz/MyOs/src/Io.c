/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Io.h>


unsigned char inb( unsigned short port )
{
	asm __volatile__ (
			"inb %%dx, %%al\n"
			:: "d" (port) );
}

unsigned short inw( unsigned short port )
{
	asm __volatile__ (
			"inw %%dx, %%ax\n"
			:: "d" (port) );
}

void outb( unsigned short port, unsigned char data )
{
	asm __volatile__ (
			"outb %%al, %%dx\n"
			:: "d" (port), "a" (data) );
}

void outw( unsigned short port, unsigned short data )
{
	asm __volatile__ (
			"outw %%ax, %%dx\n"
			:: "d" (port), "a" (data) );
}
