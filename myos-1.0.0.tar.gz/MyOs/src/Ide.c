/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Ide.h>
#include <Irq.h>


/* ide status �� Ȯ���Ѵ�... */
#define	busy_ide()		while( inb(0x1f7)&IDE_BUSY )
#define	ready_ide()		while( !(inb(0x1f7)&IDE_READY) )
#define	ready_data()	while( !(inb(0x1f7)&DATA_READY) )


/* ���� ��밡���� ��ɵ�... */
enum
{
	READ_IDE	= 1,
	WRITE_IDE
};


/* request structure type... */
typedef struct _requestIde	RequestIde;
struct _requestIde
{
	unsigned int	cylinder;
	unsigned int	head;
	unsigned int	sector;
	
	unsigned int	sectors;
	
	unsigned char	*buffer;

	int	type;
};


static unsigned int	headsPerCylinder;
static unsigned int	sectorsPerTrack;

static RequestIde	request;


static void convert_chs( unsigned int lba )
{
	unsigned int	temp;

	request.cylinder	= lba / (headsPerCylinder * sectorsPerTrack);
	
	temp	= lba % (headsPerCylinder * sectorsPerTrack );
	
	request.head	= temp / sectorsPerTrack;
	request.sector	= temp % sectorsPerTrack + 1;
}
	
void write_ide( char *buffer, int lba, int sectors )
{
	int	i;

	request.type	= WRITE_IDE;
	request.sectors	= sectors;
	request.buffer	= buffer;

	convert_chs( lba );
	

	busy_ide();
	
	ready_ide();

	outb( 0x1f2, request.sectors );
	outb( 0x1f3, request.sector );
	outb( 0x1f4, request.cylinder );
	outb( 0x1f5, request.cylinder>>8 );
	outb( 0x1f6, 0xa0|request.head );

	outb( 0x1f1, 0 );

	busy_ide();
	
	outb( 0x1f7, 0x30 );

	ready_data();
	
	for( i = 0; i < request.sectors * SECTOR_SIZE; i += 2 )
	{
		outw( 0x1f0, *(short *)request.buffer );
		request.buffer	+= 2;
	}
}

void read_ide( char *buffer, int lba, int sectors )
{	
	request.type	= READ_IDE;
	request.sectors	= sectors;
	request.buffer	= buffer;

	convert_chs( lba );


	busy_ide();
	
	ready_ide();

	outb( 0x1f2, request.sectors );
	outb( 0x1f3, request.sector );
	outb( 0x1f4, request.cylinder );
	outb( 0x1f5, request.cylinder>>8 );
	outb( 0x1f6, 0xa0|request.head );

	outb( 0x1f1, 0 );

	busy_ide();
	
	outb( 0x1f7, 0x20 );
}

static void handle_ide( void )
{
	int	i;


	switch( request.type )
	{
		case	WRITE_IDE:
			/* ���� ���� ���� ����� ���� �������� �ʾҴ�... */
			
			break;

		case	READ_IDE:
			for( i = 0; i < request.sectors * SECTOR_SIZE; i += 2 )
			{
				*(short *)request.buffer	= inw( 0x1f0 );
				request.buffer	+= 2;
			}

			break;
	}
}

/* �Ǹ����� ������� Ʈ���� ���ͼ��� ���Ѵ�... */
static void info_ide( void )
{
	unsigned short	info[256];

	int	i;
	
	
	busy_ide();

	outb( 0x1f6, 0xa0 );

	outb( 0x1f7, 0xec );

	ready_ide();

	for( i = 0; i < 256; i++ )
		info[i]	= inw(0x1f0);

	headsPerCylinder	= info[3];
	sectorsPerTrack		= info[6];
}

void init_ide( void )
{
	/* ide �� 14 irq �� ����Ѵ�... */
	register_irq_handler( 14, handle_ide );

	enable_irq( 14 );

	/* ide �� �ٷ궧 �ʿ��� �������� �����Ѵ�... */
	info_ide();
}
