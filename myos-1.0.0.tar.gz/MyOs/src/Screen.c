/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Types.h>
#include <Screen.h>
#include <Device.h>
#include <Process.h>
#include <Idt.h>
#include <Keyboard.h>


static inline void set_cursor( ScreenInfo *info )
{
	info->currentPosition	= info->screenStart
							+ ( (info->y*info->columns + info->x) << 1 );
	
	cli();

	outb( 0x3d4, 14 );
	outb( 0x3d5, 0xff&(info->currentPosition-info->screenBase)>>9 );
	outb( 0x3d4, 15 );
	outb( 0x3d5, 0xff&(info->currentPosition-info->screenBase)>>1 );

	sti();
}

static inline void set_position( ScreenInfo *info )
{
	cli();

	outb( 0x3d4, 12 );
	outb( 0x3d5, 0xff&(info->screenStart-info->screenBase)>>9 );
	outb( 0x3d4, 13 );
	outb( 0x3d5, 0xff&(info->screenStart-info->screenBase)>>1 );

	sti();
}

static inline void scroll_up( ScreenInfo *info )
{
	info->screenStart	-= info->columns<<1;
	info->screenEnd		-= info->columns<<1;

	set_position( info );
}
	
static inline void scroll_down( ScreenInfo *info )
{
	if( info->screenEnd >= info->screenLimit )
	{
		char *moveFrom, *moveTo;
		int	*p;

		moveFrom	= (char *)(info->screenLimit - SCREEN_SIZE*2);
		moveTo		= (char *)info->screenBase;

		m_memcpy( moveTo, moveFrom, SCREEN_SIZE*2 );

		p	= (int *)(info->screenBase + SCREEN_SIZE*2);
				
		for( ;p <= (int *)info->screenLimit; p++ )
			*p	= 0;
		
		info->screenStart	= info->screenBase + SCREEN_SIZE;
		info->screenEnd		= info->screenStart + SCREEN_SIZE;
	}

	info->screenStart	+= info->columns<<1;
	info->screenEnd		+= info->columns<<1;
	
	set_position( info );
}

static inline void put_enter( ScreenInfo *info )
{
	info->x	= 0;
	
	if( info->y >= info->lines-1 )
		scroll_down( info );
	else
		info->y++;

	set_cursor( info );
}

static inline void put_tab( ScreenInfo *info )
{
	while( ++info->x % 4 );

	set_cursor( info );
}

static inline void put_backspace( ScreenInfo *info )
{
	if( info->x == 0 )
		return;

	info->x--;

	set_cursor( info );

	((char *)info->currentPosition)[0]	= ' ';
	((char *)info->currentPosition)[1]	= info->attr;
}

static inline void put_down( ScreenInfo *info )
{
	if( info->currentPosition <= info->screenEnd )
		return;
	
	scroll_down( info );
}

static inline void put_up( ScreenInfo *info )
{
	if( info->screenStart <= info->screenBase )
		return;

	scroll_up( info );
}

	
typedef void (*HandleFunckey)( ScreenInfo * );

/* function key handler table... */
static HandleFunckey funckeyTable[48] = {
	put_backspace, NULL, NULL, NULL, 
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	put_down, NULL, NULL, NULL,
	NULL, NULL, put_up, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL
};

void put_char( ScreenInfo *info, char data )
{
	if( !(data & 0x80) )
	{
		switch( data )
		{
			case	'\n':
				put_enter( info );
				break;
			
			case	'\t':
				put_tab( info );
				break;
			
			default:
				((char *)info->currentPosition)[0]	= data;
				((char *)info->currentPosition)[1]	= info->attr;
				
				info->x++;
				
				if( info->x < info->columns )
					set_cursor( info );
				else			
					put_enter( info );
		}
			
		return;
	}
	
	if( funckeyTable[data&0x7f] != NULL )
		funckeyTable[data&0x7f]( info );
}

/* �ӽ÷� ȭ�� ��� ���� ������ �Լ���... */
void gotoxy( unsigned int x, unsigned int y )
{
	ScreenInfo	*info = &current->screenInfo;

	
	if( y > info->lines || x > info->columns )
		return;

	info->x	= x;
	info->y	= y;
	
	info->currentPosition	= info->screenStart
							+ ( (info->y*info->columns + info->x) << 1 );
}

void putch( char data )
{
	ScreenInfo	*info = &current->screenInfo;


	((char *)info->currentPosition)[0]	= data;
	((char *)info->currentPosition)[1]	= info->attr;
}

void set_attr( int attr )
{
	ScreenInfo	*info = &current->screenInfo;
	
	info->attr	= attr;
}

void clear_screen( void )
{
	ScreenInfo	*info = &current->screenInfo;

	int	*p = (int *)info->screenStart;


	for( ; p <= (int *)info->screenEnd; p++ )
		*p	= 0;

	info->x	= 0;
	info->y	= 0;

	set_cursor( info );
}

	
/* register device driver... */
static const char	*deviceName = "screen";

static int	write_screen( const char *, int );

/* screen device operation function table... */
static DeviceOperation screenOperation = {
	NULL,
	NULL,
	NULL,
	write_screen,
	NULL,
	NULL
};


void init_screen( void )
{
	register_device_table( deviceName, &screenOperation );
}

void init_screen_info( ScreenInfo *info )
{
	info->screenBase	= SCREEN_BASE_ADDRESS;
	info->screenLimit	= SCREEN_LIMIT_ADDRESS;
	info->screenStart	= SCREEN_BASE_ADDRESS;
	info->screenEnd		= SCREEN_BASE_ADDRESS + SCREEN_SIZE;

	info->lines			= SCREEN_LINES;
	info->columns		= SCREEN_COLUMNS;

	info->attr	= 0xc;

	info->x		= 0;
	info->y		= 0;
	
	set_cursor( info );
}

static int write_screen( const char *buffer, int size )
{
	ScreenInfo	*info = &current->screenInfo;

	int	i;

	
	for( i = 0; i < size; i++ )
		put_char( info, buffer[i] );

	return size;
}
