/******************************************************************************
 * MyOs	- my special operating system...
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Schedule.h>
#include <Process.h>
#include <Page.h>
#include <Types.h>
#include <Timer.h>


extern Tss	*initTss;

int scheduling;


static ProcessTable *get_next_process( void )
{
	ProcessTable	*next = initProcess;
	ProcessTable	*p;


	/* ��� process counter �� �����Ѵ�... */
	p	= LIST_ENTRY( initProcess->running.next, ProcessTable, running );
	
	while( p != initProcess )
	{
		/* p->sleep > 0 : process is sleeping... */
		if( p->sleep && p->sleep < tick )
		{
			p->sleep	= 0;
			p->status	= PROCESS_RUNNING;
		}
			
		if( p->status == PROCESS_RUNNING )
		{
			p->counter	= ( p->counter >> 1 ) + p->priority;

			if( next == initProcess || next->counter < p->counter )
				next	= p;
		}

		p	= LIST_ENTRY( p->running.next, ProcessTable, running );
	}

	return next;
}


void schedule( void )
{
	ProcessTable	*prev = current;
	ProcessTable	*next;


	next	= get_next_process();

	/* initTss->esp0 �� ������ ����� process �� esp0 ���� �ٲ۴�... */
	initTss->esp0	= next->thread.esp0;

	/* cr3 �� ������ ����� process �� page directory �� �ٲ۴�... */
	load_cr3( get_phys_to_addr(next->thread.cr3) );

	scheduling	= 0;
	
	asm __volatile__ (
			"pushl %%ebp\n"
			"movl %%esp, %0\n"
			"movl %2, %%esp\n"
			"movl $1f, %1\n"
			"jmp *%3\n"
			"1:\n"
			"popl %%ebp\n"
			: "=m" (prev->thread.esp), "=m" (prev->thread.eip)
			: "m" (next->thread.esp), "m" (next->thread.eip)
			);
}
