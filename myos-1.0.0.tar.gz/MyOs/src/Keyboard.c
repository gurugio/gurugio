/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Types.h>
#include <Irq.h>
#include <Device.h>
#include <WaitQueue.h>
#include <Process.h>
#include <Syscall.h>
#include <Schedule.h>


extern void	put_char( ScreenInfo *, char );


static void	handle_keyboard( void );
static void	wait_keyboard( void );
static void	set_led( void );


static WaitQueue	waitQueue;

static unsigned char	ledStatus;
static unsigned int		funcStatus;


typedef void (*HandleScancode)( unsigned char );

static HandleScancode	keyTable[256];

static char	normalKey[128];
static char	shiftKey[128];


/* ���� ����� ������ ���� �ʴ´�...������ �𸣰���... */
static void set_led( void )
{
	outb( 0x60, 0xed );

	wait_keyboard();

	outb( 0x60, ledStatus );
}

static void wait_keyboard( void )
{
	while( inb(0x64) & 0x2 );
}

static void do_nothing( unsigned char scancode )
{
	char	*keymap = normalKey;
	

	if( (ledStatus&CAPS_FLAG)^(funcStatus&SHIFT_FLAG) )
		keymap	= shiftKey;

	if( !(keymap[scancode] & 0x80) )
		foreground->inputInfo.queue[foreground->inputInfo.offset++]	=
															keymap[scancode];

	put_char( &foreground->screenInfo, keymap[scancode] );
}

static void do_enter( unsigned char scancode )
{
	put_char( &foreground->screenInfo, normalKey[scancode] );
	
	if( foreground->inputInfo.offset )
		foreground->inputInfo.queue[foreground->inputInfo.offset++]	=
															normalKey[scancode];
	
	del_wait_queue( &waitQueue, foreground );

	scheduling	= 1;
}

static void do_backspace( unsigned char scancode )
{
	if( !foreground->inputInfo.offset )
		return;

	foreground->inputInfo.offset--;

	foreground->inputInfo.queue[foreground->inputInfo.offset]	= ' ';

	put_char( &foreground->screenInfo, normalKey[scancode] );
}

static void do_ctrl( unsigned char scancode )
{
	funcStatus	|= CTRL_FLAG;
}

static void do_unctrl( unsigned char scancode )
{
	funcStatus	&= ~CTRL_FLAG;
}

static void do_alt( unsigned char scancode )
{
	funcStatus	|= ALT_FLAG;
}

static void do_unalt( unsigned char scancode )
{
	funcStatus	&= ~ALT_FLAG;
}

static void do_lshift( unsigned char scancode )
{
	funcStatus	|= SHIFT_FLAG;
}

static void do_unlshift( unsigned char scancode )
{
	funcStatus	&= ~SHIFT_FLAG;
}

static void do_rshift( unsigned char scancode )
{
	funcStatus	|= SHIFT_FLAG;
}

static void do_unrshift( unsigned char scancode )
{
	funcStatus	&= ~SHIFT_FLAG;
}

static void do_num( unsigned char scancode )
{
	ledStatus	^= NUM_FLAG;

	set_led();
}

static void do_scroll( unsigned char scancode )
{
	ledStatus	^= SCROLL_FLAG;

	set_led();
}

static void do_caps( unsigned char scancode )
{
	ledStatus	^= CAPS_FLAG;
	
	set_led();
}

/* default key handler table... */
static HandleScancode	keyTable[256] = {
	NULL, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_backspace, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_enter, do_ctrl, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_lshift, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_rshift, do_nothing,
	do_alt, do_nothing, do_caps, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_num, do_scroll, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	do_nothing, do_nothing, do_nothing, do_nothing,
	NULL, NULL, do_nothing, do_nothing,
	do_nothing, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, do_unctrl, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, do_unlshift, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, do_unrshift, NULL,
	do_unalt, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL
};

/* normal keymap table... */
static char normalKey[128] = {
	0, 0x1b, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 
	0x38, 0x39, 0x30, 0x2d, 0x3d, BACKSPACE, 0x09, 0x71,
	0x77, 0x65, 0x72, 0x74, 0x79, 0x75, 0x69, 0x6f, 
	0x70, 0x5b, 0x5d, 0xa, CONTROL, 0x61, 0x73, 0x64,
	0x66, 0x67, 0x68, 0x6a, 0x6b, 0x6c, 0x3b, 0x27,
	0, SHIFT, 0x5c, 0x7a, 0x78, 0x63, 0x76, 0x62,
	0x6e, 0x6d, 0x2c, 0x2e, 0x2f, SHIFT, KP_MULTIPLY, ALT,
	0x20, CAPS_LOCK, F1, F2, F3, F4, F5, F6,
	F7, F8, F9, F10, NUM_LOCK, SCROLL_LOCK, KP_7, KP_8,
	KP_9, KP_SUBTRACT, KP_4, KP_5, KP_6, KP_ADD, KP_1, KP_2,
	KP_3, KP_0, KP_PERIOD, 0, 0, 0, F11, F12,
	0, 0, 0, 0, 0, 0, 0, KP_ENTER,
	CONTROL, KP_DIVIDE, 0, ALT, 0, 0, UP, 0,
	LEFT, RIGHT, SELECT, DOWN, NEXT, INSERT, DELETE, 0, 
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0
};

/* shift keymap table... */
static char shiftKey[128] = {
	0, 0x1b, 0x21, 0x40, 0x23, 0x24, 0x25, 0x53, 0x26, 
	0x2a, 0x28, 0x29, 0x5f, 0x2b, BACKSPACE, 0x09, 0x51, 
	0x57, 0x45, 0x52, 0x54, 0x59, 0x55, 0x49, 0x4f, 
	0x50, 0x7b, 0x7d, 0xa, CONTROL, 0x41, 0x53, 0x44,
	0x46, 0x47, 0x48, 0x4a, 0x4b, 0x4c, 0x3a, 0x22, 
	0, SHIFT, 0x7c, 0x5a, 0x58, 0x43, 0x56, 0x42,
	0x4e, 0x4d, 0x3c, 0x3e, 0x3f, SHIFT, KP_MULTIPLY, ALT,
	0x20, CAPS_LOCK, F1, F2, F3, F4, F5, F6, 
	F7, F8, F9, F10, NUM_LOCK, SCROLL_LOCK, KP_7, KP_8,
	KP_9, KP_SUBTRACT, KP_4, KP_5, KP_6, KP_ADD, KP_1, KP_2,
	KP_3, KP_0, KP_PERIOD, 0, 0, 0, F11, F12,
	0, 0, 0, 0, 0, 0, 0, KP_ENTER,
	CONTROL, KP_DIVIDE, 0, ALT, 0, 0, UP, 0,
	LEFT, RIGHT, SELECT, DOWN, NEXT, INSERT, DELETE, 0, 
	0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0
};


/* register device driver... */
static const char	*deviceName = "keyboard";

static int	read_keyboard( char *, int );
static int	ioctl_keyboard( int );

/* keyboard device operation function table... */
static DeviceOperation keyboardOperation = {
	NULL,
	NULL,
	read_keyboard,
	NULL,
	NULL,
	ioctl_keyboard
};


void init_keyboard( void )
{
	register_device_table( deviceName, &keyboardOperation );
	
	register_irq_handler( 1, handle_keyboard );

	enable_irq( 1 );

	ledStatus	= 0;
	funcStatus	= 0;

	set_led();

	INIT_WAIT_QUEUE(&waitQueue);
}

static void handle_keyboard( void )
{
	unsigned char	scancode;
	

	scancode	= inb( 0x60 );
	
	/* RAW_MODE �̸� scancode �� �ѱ�� �ٷ� ���μ����� �����... */
	if( foreground->inputInfo.mode & RAW_MODE )
	{
		foreground->inputInfo.queue[foreground->inputInfo.offset++]	= scancode;

		scheduling	= 1;

		return;
	}

	if( scancode == 0xe0 || scancode == 0xe1 )
	{
		scancode	= inb( 0x61 );
		scancode	|= 0x80;
		outb( 0x61, scancode );
		scancode	&= 0x7f;
		outb( 0x61, scancode );

		return;
	}

	if( keyTable[scancode] != NULL )
		keyTable[scancode]( scancode );
}

static int read_keyboard( char *buffer, int size )
{
	ProcessTable	*p = current;

	int	ret;
	
	
	p->inputInfo.offset	= 0;

	add_wait_queue( &waitQueue, p );
	
	/* enter key �� �Է¹��������� ����ϸ鼭 buffer �� key value �� �����Ѵ�...
	 */
	schedule();

	del_wait_queue( &waitQueue, p );

	ret	= m_strncpy( buffer, p->inputInfo.queue, p->inputInfo.offset );

	return ret;
}

static int ioctl_keyboard( int command )
{
	ProcessTable	*p = current;

	
	/* RAW_MODE �� scancode �� �״�� �Ѱܹ޴´�... */
	switch( command )
	{
		case	RAW_MODE:
			p->inputInfo.mode	= RAW_MODE;
			break;

		case	COOKED_MODE:
			p->inputInfo.mode	= COOKED_MODE;
			break;
	}

	return 0;
}
