/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Idt.h>
#include <Gdt.h>
#include <Syscall.h>
#include <Irq.h>


extern void	ignore_int( void );

extern void	divide_error( void );
extern void	debug( void );
extern void	nmi( void );
extern void	breakpoint( void );
extern void	overflow( void );
extern void	bound_range_exceeded( void );
extern void	invalid_opcode( void );
extern void	nomath( void );
extern void	doublefault( void );
extern void	reserved_1( void );
extern void	invalid_tss( void );
extern void	segment_not_present( void );
extern void	stack_segment_fault( void );
extern void	general_protection( void );
extern void	page_fault( void );
extern void	reserved_2( void );
extern void	math_fault( void );
extern void	alignment_check( void );
extern void	machine_check( void );
extern void	floating_point_exception( void );

extern void	handle_syscall( void );


#define	DECLARE_IRQ(num)	\
		extern void	handle_irq_##num( void );	\
		set_int_desc(IRQ_VECTOR+num,handle_irq_##num)


/* idt �� Setup.asm ���� �����ϸ� kernel ������ �װ��� ����Ѵ�...not good! */
static IdtDesc	*idt = (IdtDesc *)0xc0091000;


void set_idt_desc( int num, unsigned long func, int type, int selector )
{
	idt[num].l	= (unsigned long)(func & 0xffff)
				| (unsigned long)((selector<<16)&0xffff0000);
	idt[num].h	= (unsigned long)(func & 0xffff0000)
				| (unsigned long)(type & 0xffff);
}

void init_idt( void )
{
	int	i;


	/* exception handler �� ����Ѵ�. ������ Ư���� ����� ���� �ٷ� 
	 * panic �� �߻���Ų��...
	 */
	set_trap_desc( 0, divide_error );
	set_trap_desc( 1, debug );
	set_int_desc( 2, nmi );
	set_sys_desc( 3, breakpoint );
	set_sys_desc( 4, overflow );
	set_sys_desc( 5, bound_range_exceeded );
	set_trap_desc( 6, invalid_opcode );
	set_trap_desc( 7, nomath );
	set_trap_desc( 8, doublefault );
	set_trap_desc( 9, reserved_1 );
	set_trap_desc( 10, invalid_tss );
	set_trap_desc( 11, segment_not_present );
	set_trap_desc( 12, stack_segment_fault );
	set_trap_desc( 13, general_protection );
	set_int_desc( 14, page_fault );
	set_trap_desc( 15, reserved_2 );
	set_trap_desc( 16, math_fault );
	set_trap_desc( 17, alignment_check );
	set_trap_desc( 18, machine_check );
	set_trap_desc( 19, floating_point_exception );

	for( i = 20; i < 256; i++ )
		set_trap_desc( i, ignore_int );

	/* hardware interrupt handler �� ����Ѵ�. ���⼭�� �ʱ� ���� handler ��
	 * ����ϸ� ���Ŀ� ������ irq �� ����ϴ� device driver ���� ���� handler
	 * �� ����ؼ� ����Ѵ�...
	 */
	DECLARE_IRQ(0);
	DECLARE_IRQ(1);
	DECLARE_IRQ(2);
	DECLARE_IRQ(3);
	DECLARE_IRQ(4);
	DECLARE_IRQ(5);
	DECLARE_IRQ(6);
	DECLARE_IRQ(7);
	DECLARE_IRQ(8);
	DECLARE_IRQ(9);
	DECLARE_IRQ(10);
	DECLARE_IRQ(11);
	DECLARE_IRQ(12);
	DECLARE_IRQ(13);
	DECLARE_IRQ(14);
	DECLARE_IRQ(15);
	
	/* system call handler �� ����Ѵ�... */
	set_sys_desc( SYSCALL_VECTOR, handle_syscall );
}
