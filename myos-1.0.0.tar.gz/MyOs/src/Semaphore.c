/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Semaphore.h>


void init_sema( Sema *sema, unsigned int count )
{
	INIT_WAIT_QUEUE( &sema->queue );

	sema->count	= count;
}


static void down_sleep( Sema *sema )
{
	add_wait_queue( &sema->queue, current );
		
	schedule();
}

static void up_wakeup( Sema *sema )
{
	del_wait_queue_by_seq( &sema->queue, WAKE_UP_ONE );
}

void up( Sema *sema )
{
	asm __volatile__ (
			"incl %0\n"
			"jg 1f\n"
			"push %%edx\n"
			"call up_wakeup\n"
			"pop %%edx\n"
			"1:\n"
			:: "m" (sema->count), "d" (sema) 
			);
}

void down( Sema *sema )
{
	asm __volatile__ (
			"decl %0\n"
			"jns 1f\n"
			"push %%edx\n"
			"call down_sleep\n"
			"pop %%edx\n"
			"1:\n"
			:: "m" (sema->count), "d" (sema)
			);
}
