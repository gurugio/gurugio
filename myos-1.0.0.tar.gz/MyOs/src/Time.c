/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#include <Time.h>



/* ���� �������� �ʾ���... */
void init_time( void )
{
	Time	t;
	
	outb( 0x70, 0x80 );
	t.sec	= inb( 0x71 );
	
	outb( 0x70, 0x82 );
	t.min	= inb( 0x71 );
	
	outb( 0x70, 0x84 );
	t.hour	= inb( 0x71 );
	
	outb( 0x70, 0x87 );
	t.day	= inb( 0x71 );
		
	outb( 0x70, 0x88 );
	t.mon	= inb( 0x71 );
	
	outb( 0x70, 0x89 );
	t.year	= inb( 0x71 );
}
