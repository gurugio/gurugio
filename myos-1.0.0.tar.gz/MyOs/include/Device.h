/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__DEVICE_H__
#define	__DEVICE_H__


#include "List.h"


#define	MAX_DEVICE_NAME		32


/* device operation table... */
typedef struct _deviceOperation	DeviceOperation;
struct _deviceOperation
{
	int	(*open)( void );
	int	(*close)( void );
	int	(*read)( char *, int );
	int	(*write)( const char *, int );
	int	(*seek)( int, int );
	int	(*ioctl)( int );
};
	

typedef struct _deviceTable		DeviceTable;
struct _deviceTable
{
	DECLARE_LIST(index);

	char	name[MAX_DEVICE_NAME];

	DeviceOperation	*op;
};


extern int	register_device_table( const char *, DeviceOperation * );
extern int	unregister_device_table( const char * );

extern DeviceTable	*search_device_table( const char * );


typedef struct _device		Device;
struct _device
{
	char	name[MAX_DEVICE_NAME];
	
	int	offset;

	DeviceOperation	*op;
};


#endif
