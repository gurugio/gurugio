/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__WAIT_QUEUE_H__
#define	__WAIT_QUEUE_H__


#include "Process.h"


#define	WAKE_UP_ONE		(1<<0)
#define	WAKE_UP_ALL		(1<<1)


typedef struct _waitQueue	WaitQueue;
struct _waitQueue
{
	ProcessTable	*waitProcess;
		
	DECLARE_LIST(waiting);
};


#define	INIT_WAIT_QUEUE(queue)			INIT_LIST(&((queue)->waiting))

#define	INSERT_WAIT_QUEUE(queue,node)	\
						INSERT_LIST_TAIL(&((queue)->waiting),&((node)->waiting))

#define	DELETE_WAIT_QUEUE(queue,node)	\
						DELETE_LIST(&((queue)->waiting),&((node)->waiting))

#define	SEARCH_WAIT_QUEUE(queue,node)	SEARCH_LIST(&((queue)->waiting),node)
#define	WAIT_QUEUE_ENTRY(node)			LIST_ENTRY(node,WaitQueue,waiting)
	

extern void	add_wait_queue( WaitQueue *, ProcessTable * );
extern void	del_wait_queue( WaitQueue *, ProcessTable * );

extern void	del_wait_queue_by_seq( WaitQueue *, unsigned int );


#endif
