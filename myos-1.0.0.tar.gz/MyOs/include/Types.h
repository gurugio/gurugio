/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__TYPES_H__
#define	__TYPES_H__


#define	NULL	(void *)0


typedef struct _regsInStack		RegsInStack;
struct _regsInStack
{
	unsigned int	ebx;
	unsigned int	ecx;
	unsigned int	edx;
	unsigned int	edi;
	unsigned int	esi;
	unsigned int	ebp;
	unsigned int	ds;
	unsigned int	es;
	unsigned int	eax;
	
	unsigned int	eip;
	unsigned int	cs;
	unsigned int	eflags;
	unsigned int	esp;
	unsigned int	ss;
};


#endif
