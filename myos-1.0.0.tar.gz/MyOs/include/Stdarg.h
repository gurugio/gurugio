/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__STDARG_H__
#define	__STDARG_H__


typedef int		va_list;


#define	va_start(ap,arg)	(ap = (int)&arg + sizeof(int))
#define	va_arg(ap,type)		*(type *)ap; ap += sizeof(int);
#define	va_end(ap)		


#endif
