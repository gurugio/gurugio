/******************************************************************************
 * MyOs	- my special operating system...
 *
 * 
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__PROCESS_H__
#define	__PROCESS_H__


#include "List.h"
#include "Device.h"
#include "Keyboard.h"
#include "Screen.h"
#include "Ext2.h"


/* declare process's statements... */
#define	PROCESS_RUNNING				1
#define	PROCESS_INTERRUPTIBLE		2
#define	PROCESS_UNINTERRUPTIBLE		3
#define	PROCESS_STOPPED				4


/* task state segment... */
typedef struct _tss		Tss;
struct _tss
{
	unsigned short	backLink, _blh;
	unsigned long	esp0;
	unsigned short	ss0, _ss0h;
	unsigned long	esp1;
	unsigned short	ss1, _ss1h;
	unsigned long	esp2;
	unsigned short	ss2, _ss2h;
	unsigned long	cr3, eip, eflags;
	unsigned long	eax, ecx, edx, ebx;
	unsigned long	esp, ebp, esi, edi;
	unsigned short	es, _esh;
	unsigned short	cs, _csh;
	unsigned short	ss, _ssh;
	unsigned short	ds, _dsh;
	unsigned short	fs, _fsh;
	unsigned short	gs, _gsh;
	unsigned short	ldt, _ldth;
	unsigned short	trace, bitmap;
};

/* thread structure... */
typedef struct _thread	Thread;
struct _thread
{
	unsigned int	eip;
	unsigned int	esp;
	unsigned int	esp0;
	unsigned int	cr3;
};


#define	MAX_DEVICE_OPEN		16


/* process table... */
typedef struct _processTable	ProcessTable;
struct _processTable
{
	int	status;
	int	pid;
	
	unsigned int	priority;
	unsigned int	counter;

	unsigned int	sleep;

	DECLARE_LIST(running);

	Thread	thread;
	
	/* console... */
	InputInfo	inputInfo;
	ScreenInfo	screenInfo;
	
	/* current directory... */
	Dentry	*root, *pwd;
	
	/* access device driver... */
	Device	*device[MAX_DEVICE_OPEN];
};


#define	PROCESS_STACK_SIZE	4096

#define	NORMAL_PRIORITY		20
#define	FOREGROUND_PRIORITY	40

#define	INIT_PID	0

/* process table �� kernel mode stack �� �ϳ��� page �� �����Ѵ�... */
typedef union _processStack		ProcessStack;
union _processStack
{
	ProcessTable	pt;

	unsigned char	stack[ PROCESS_STACK_SIZE ];
};


/* ���� esp ������ current process table �� ���Ѵ�... */
static inline ProcessTable *get_current_process( void )
{
	asm __volatile__ ( 
			"movl %esp, %eax\n"
			"andl $0xfffff000, %eax\n"
			);
}

#define	current		get_current_process()
	
#define	create_process_table()	(ProcessTable *)alloc_kernel_cache()


extern ProcessTable	*initProcess;
extern ProcessTable	*foreground;

extern void	create_thread( int (*)(void) );

extern void	set_to_foreground( void );

	
#endif
