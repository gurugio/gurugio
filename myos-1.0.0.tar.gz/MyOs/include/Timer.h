/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__TIMER_H__
#define	__TIMER_H__


extern unsigned int	tick;


#define	HZ_SECOND	100

#define	PIT_CLOCK_RATE		1193180

#define	PIT_LATCH	(PIT_CLOCK_RATE/HZ_SECOND)


#endif
