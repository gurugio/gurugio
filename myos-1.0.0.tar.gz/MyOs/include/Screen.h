/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__CONSOLE_H__
#define	__CONSOLE_H__


#define	SCREEN_BASE_ADDRESS		0xc00b8000
#define	SCREEN_LIMIT_ADDRESS	0xc00bfee0
#define	SCREEN_LINES			25
#define	SCREEN_COLUMNS			80
#define	SCREEN_SIZE				4000


#define	SET_COLOR(back,fore)	((back << 4) & 0xf0) | (fore & 0xf)


typedef struct _screenInfo		ScreenInfo;
struct _screenInfo
{
	unsigned int	screenBase, screenLimit;

	unsigned int	screenStart, screenEnd;

	unsigned int	currentPosition;
	
	unsigned int	attr;

	unsigned int	x, y;

	unsigned int	lines, columns;
};


extern void	init_screen_info( ScreenInfo * );

extern void	gotoxy( unsigned int, unsigned int );
extern void	putch( char );
extern void	set_attr( int );
extern void	clear_screen( void );


#endif
