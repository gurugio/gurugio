/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__SEMAPHORE_H__
#define	__SEMAPHORE_H__


#include "WaitQueue.h"


typedef struct _sema	Sema;
struct _sema
{
	WaitQueue	queue;

	unsigned int	count;
};


extern void	init_sema( Sema *, unsigned int );
extern void	up( Sema * );
extern void	down( Sema * );


#endif
