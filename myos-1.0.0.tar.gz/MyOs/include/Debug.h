#ifndef	__DEBUG_H__
#define	__DEBUG_H__


#ifdef	DEBUG

#define	CHECK(status)	\
if( !status )	\
{	\
	m_print( "%s : Check error in %s[%d]...!\n", #status, __FILE__, __LINE__ );\
	cli();	\
	while(1);	\
}

#define	VERIFY(message)	\
m_print( "%s : Verify in %s[%d]...!\n", #message, __FILE__, __LINE__ );

#else

#define	CHECK(status)	
#define	VERIFY(message)

#endif

#endif
