/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__TIME_H__
#define	__TIME_H__


typedef struct _time	Time;
struct _time
{
	unsigned int	sec;
	unsigned int	min;
	unsigned int	hour;
	unsigned int	day;
	unsigned int	mon;
	unsigned int	year;
};


#endif
