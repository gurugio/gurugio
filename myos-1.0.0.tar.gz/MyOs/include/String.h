/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__STRING_H__
#define	__STRING_H__


extern int	m_atoi( char * );
extern int	m_strlen( char * );

extern int	m_strcpy( char *, const char * );
extern int	m_strncpy( char *, const char *, int );

extern int	m_strcat( char *, const char * );

extern int	m_strcmp( char *, const char * );
extern int	m_strncmp( char *, const char *, int );


#endif
