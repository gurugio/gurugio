/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__SYSCALL_H__
#define	__SYSCALL_H__


#define	SYSCALL_VECTOR		0x80

#define	SYS_EXIT		1
#define	SYS_FORK		2
#define	SYS_PAUSE		3
#define	SYS_OPEN		4
#define	SYS_CLOSE		5
#define	SYS_READ		6
#define	SYS_WRITE		7
#define	SYS_SEEK		8
#define	SYS_IOCTL		9
#define	SYS_SLEEP		10
#define	SYS_USLEEP		11
#define	SYS_PRIORITY_UP	12
#define	SYS_MOUNT		13


#define	DECLARE_SYSCALL_0(num,name)	\
inline int name( void )	\
{	\
	asm __volatile__ (	\
			"int $0x80\n"	\
			:: "a" (num));	\
}

#define	DECLARE_SYSCALL_1(num,name,type1,arg1)	\
inline int name( type1 arg1 )	\
{	\
	asm __volatile__ (	\
			"int $0x80\n"	\
			:: "a" (num), "b" (arg1));	\
}

#define	DECLARE_SYSCALL_2(num,name,type1,arg1,type2,arg2)	\
inline int	name( type1 arg1, type2 arg2 )	\
{	\
	asm __volatile__ (	\
			"int $0x80\n"	\
			:: "a" (num), "b" (arg1), "c" (arg2) );	\
}

#define	DECLARE_SYSCALL_3(num,name,type1,arg1,type2,arg2,type3,arg3)	\
inline int	name( type1 arg1, type2 arg2, type3 arg3 )	\
{	\
	asm __volatile__ (	\
			"int $0x80\n"	\
			:: "a" (num), "b" (arg1), "c" (arg2), "d" (arg3) );	\
}


#endif
