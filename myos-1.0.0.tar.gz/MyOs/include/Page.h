/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__PAGE_H__
#define	__PAGE_H__


#define	PAGE_SIZE	4096


#define	KERNEL_USED			(1<<0)
#define	USER_USED			(1<<1)
#define	KERNEL_RESERVED		(1<<2)
#define	KERNEL_CACHE		(1<<3)


#define	PAGE_PRESENT_FLAG	(1<<0)
#define	PAGE_WRITE_FLAG		(1<<1)
#define	PAGE_USER_FLAG		(1<<2)


#define	PGD_OFFSET(addr)	(addr>>22)&0x3ff
#define	PTE_OFFSET(addr)	(addr>>12)&0x3ff


#define	KERNEL_PAGE_BASE	0xc0000000


#define	NON_PRESENT_FLAG	(1<<0)
#define	NON_WRITE_FLAG		(1<<1)
#define	NON_USER_FLAG		(1<<2)


#define	load_cr3(cr3)	\
	asm __volatile__ (	\
			"movl %0, %%cr3\n"	\
			:: "r" (cr3) )


extern unsigned int	alloc_page_frame( unsigned int, unsigned int );
extern int	free_page_frame( unsigned int );

extern unsigned int	get_addr_to_phys( unsigned int );
extern unsigned int	get_phys_to_addr( unsigned int );

extern unsigned int	alloc_kernel_cache( void );
extern int	free_kernel_cache( unsigned int );

extern int	alloc_page( unsigned int, unsigned int );
extern int	free_page( unsigned int );


#endif
