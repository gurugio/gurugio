/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__IDT_H__
#define	__IDT_H__


#include "Types.h"


typedef struct _idtDesc		IdtDesc;
struct _idtDesc
{
	unsigned long	l, h;
};

void set_idt_desc( int, unsigned long, int, int );

	
/* inline assembly... */
#define	cli()	asm ( "cli" )
#define	sti()	asm ( "sti" )


/* set hardware interrupt descriptor... */
#define	set_int_desc(num,func)	\
					set_idt_desc(num,(unsigned long)func,0x8e00,KERNEL_CODE)
/* set trap descriptor... */
#define	set_trap_desc(num,func)	\
					set_idt_desc(num,(unsigned long)func,0x8f00,KERNEL_CODE) 
/* set syscall descriptor... */
#define	set_sys_desc(num,func)	\
					set_idt_desc(num,(unsigned long)func,0xef00,KERNEL_CODE)

#endif
