/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__KEYBOARD_H__
#define	__KEYBOARD_H__


#define	MAX_INPUT_QUEUE_SIZE		160


#define	RAW_MODE		(1<<0)
#define	COOKED_MODE		(1<<1)


typedef struct _inputInfo	InputInfo;
struct _inputInfo
{
	char	queue[ MAX_INPUT_QUEUE_SIZE ];

	int	offset;

	int	mode;
};



#define	SCROLL_FLAG		(1<<0)
#define	NUM_FLAG		(1<<1)
#define	CAPS_FLAG		(1<<2)

#define	CTRL_FLAG		(1<<0)
#define	ALT_FLAG		(1<<1)
#define	SHIFT_FLAG		(1<<2)


#define	CONTROL			0
#define	SHIFT			0
#define	ALT				0
#define	CAPS_LOCK		0
#define	NUM_LOCK		0
#define	SCROLL_LOCK		0
#define	BACKSPACE		0x80
#define	F1				0x81
#define	F2				0x82
#define	F3				0x83
#define	F4				0x84
#define	F5				0x85
#define	F6				0x86
#define	F7				0x87
#define	F8				0x88
#define	F9				0x89
#define	F10				0x8a
#define	F11				0x8b
#define	F12				0x8c
#define	KP_0			0x8d
#define	KP_1			0x8e
#define	KP_2			0x8f
#define	KP_3			0x90
#define	KP_4			0x91
#define	KP_5			0x92
#define	KP_6			0x93
#define	KP_7			0x94	
#define	KP_8			0x95
#define	KP_9			0x96
#define	KP_ADD			0x97
#define	KP_PERIOD		0x98
#define	KP_SUBTRACT		0x99
#define	KP_ENTER		0x9a
#define	KP_DIVIDE		0x9b
#define	KP_MULTIPLY		0x9c
#define	UP				0x9d
#define	LEFT			0x9e
#define	RIGHT			0x9f
#define	SELECT			0xa0
#define	DOWN			0xa1
#define	NEXT			0xa2
#define	INSERT			0xa3
#define	DELETE			0xa4


#endif
