/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__IO_H__
#define	__IO_H__


extern unsigned char 	inb( unsigned short );
extern unsigned short	inw( unsigned short );

extern void	outb( unsigned short, unsigned char );
extern void	outw( unsigned short, unsigned short );


#endif

