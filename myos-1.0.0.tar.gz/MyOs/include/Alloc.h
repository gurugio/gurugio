/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__ALLOC_H__
#define	__ALLOC_H__


#include "List.h"


typedef struct _memBlock	MemBlock;
struct _memBlock
{
	MemBlock	*freeNext;
	
	unsigned int	base;
	unsigned int	size;

	unsigned int	flags;
};

typedef struct _heapArea	HeapArea;
struct _heapArea
{
	unsigned int	base;
	unsigned int	limit;

	unsigned int	current;

	MemBlock	*freeHead;
};


#define	MEMBLOCK_HEADER_SIZE	16

#define	USED_FLAG		(1<<0)


extern int	create_heap_area( HeapArea *, unsigned int, unsigned int );
extern void	*alloc( HeapArea *, unsigned int );
extern int	free( HeapArea *, void * );


#endif
