/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__IRQ_H__
#define	__IRQ_H__


#define	MAX_IRQ		16
#define	IRQ_VECTOR	0x20


/* declare irq handler type... */
typedef void	(*IrqHandler)( void );


extern void	enable_irq( int );
extern void	disable_irq( int );

extern void	register_irq_handler( int, IrqHandler );
extern void	unregister_irq_handler( int );


#endif
