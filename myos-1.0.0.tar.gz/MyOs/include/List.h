/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__LIST_H__
#define	__LIST_H__


typedef struct _list	List;
struct _list
{
	List *next, *prev;
};


#define	DECLARE_LIST(name)	List name

#define	INIT_LIST(head)	\
	(head)->next	= (head);	\
	(head)->prev	= (head)

#define	DECLARE_LIST_HEAD(head)		List head = { &(head), &(head) }


#define	INSERT_LIST_TAIL(head,node)	\
	(node)->prev	= (head)->prev;	\
	(node)->next	= (head);		\
	(head)->prev->next	= (node);	\
	(head)->prev		= (node)

#define	INSERT_LIST_HEAD(head,node)	\
	(node)->prev	= (head);		\
	(node)->next	= (head)->next;	\
	(head)->next->prev	= (node);	\
	(head)->next		= (node)

#define	DELETE_LIST(head,node)	\
	(node)->prev->next	= (node)->next;	\
	(node)->next->prev	= (node)->prev;

#define	SEARCH_LIST(head,node)	\
	for( (node) = (head)->next; (node) != (head); (node) = (node)->next )

#define	LIST_ENTRY(node,type,name)	\
	(type *)((unsigned int)(node)-(unsigned int)(&((type *)0)->name))


#endif
