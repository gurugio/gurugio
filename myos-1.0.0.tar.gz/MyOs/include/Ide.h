/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__IDE_H__
#define	__IDE_H__


/* default sector size... */
#define	SECTOR_SIZE		512


/* ide status register flag... */
#define	IDE_BUSY	0x80
#define	IDE_READY	0x40
#define	DATA_READY	0x08


extern void	write_ide( char *, int, int );
extern void	read_ide( char *, int, int );


#endif

