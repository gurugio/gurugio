/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__KALLOC_H__
#define	__KALLOC_H__


extern void	*kalloc( unsigned int );
extern int	kfree( void * );


#endif
