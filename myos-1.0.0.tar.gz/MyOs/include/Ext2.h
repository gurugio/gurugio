/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__EXT2_H__
#define	__EXT2_H__


#define	SECTOR_SIZE		512

#define	BLOCK_SIZE		(SECTOR_SIZE << 1)

#define	INODE_TABLE_SIZE	128
#define	INODE_PER_BLOCK		(BLOCK_SIZE / INODE_TABLE_SIZE)


typedef char	__s8;
typedef short	__s16;
typedef long	__s32;

typedef unsigned char	__u8;
typedef unsigned short	__u16;
typedef unsigned long	__u32;


typedef struct _superBlock	SuperBlock;
struct _superBlock
{
	__u32	inodesCount;
	__u32	blocksCount;
	__u32	reservedBlocksCount;
	__u32	freeBlocksCount;
	__u32	freeInodesCount;
	__u32	firstDataBlock;
	__u32	logBlockSize;
	__s32	logFragSize;
	__u32	blocksPerGroup;
	__u32	fragsPerGroup;
	__u32	inodesPerGroup;
	__u32	mtime;
	__u32	wtime;
	__u16	mntCount;
	__u16	maxMntCount;
	__u16	magic;
	__u16	state;
	__u16	errors;
	__u16	minorRevLevel;
	__u32	lastCheck;
	__u32	checkInterval;
	__u32	creatorOs;
	__u32	revLevel;
	__u16	defresUid;
	__u16	defresGid;
	__u32	firstInode;
	__u16	inodeSize;
	__u16	blockGroupNum;
	__u32	featureCompat;
	__u32	featureIncompat;
	__u32	featureRoCompat;
	__u8	uuid[16];
	char	volumeName[16];
	char	lastMounted[64];
	__u32	algorithmUsageBitmap;
	__u8	preallocBlocks;
	__u8	preallocDirBlocks;
	__u16	padding;
	__u32	reserver[204];
};


typedef struct _groupDesc		GroupDesc;
struct _groupDesc
{
	__u32	blockBitmap;
	__u32	inodeBitmap;
	__u32	inodeTable;
	__u16	freeBlocksCount;
	__u16	freeInodesCount;
	__u16	usedDirsCount;
	__u16	pad;
	__u32	reserved[3];
};


typedef struct _inodeTable		InodeTable;
struct _inodeTable
{
	__u16	mode;
	__u16	uid;
	__u32	size;
	__u32	atime;
	__u32	ctime;
	__u32	mtime;
	__u32	dtime;
	__u16	gid;
	__u16	linksCount;
	__u32	blocks;
	__u32	flags;
	
	union
	{
		struct
		{
			__u32	reserved;
		} linux1;
	} spec1;
	
	__u32	block[15];
	__u32	generation;
	__u32	fileAcl;
	__u32	dirAcl;
	__u32	faddr;
	
	union
	{
		struct
		{
			__u8	frag;
			__u8	fsize;
			__u16	pad;
			__u16	uidHigh;
			__u16	gidHigh;
			__u32	reserved;
		} linux2;
	} spec2;
};

enum
{
	EXT2_UNKNOWN	= 0,
	EXT2_REG_FILE,
	EXT2_DIR,
	EXT2_CHRDEV,
	EXT2_BLKDEV,
	EXT2_FIFO,
	EXT2_SOCK,
	EXT2_SYMLINK,
	EXT2_MAX
};


/* file entry in directory... */
typedef struct _entry	Entry;
struct _entry
{
	__u32	inode;
	__u16	recLen;
	__u8	nameLen;
	__u8	fileType;
	char	name[256];
};


typedef struct _dentry	Dentry;
struct _dentry
{
	int	inode;

	InodeTable	*it;
	
	/* memory base address for file contents... */
	char	*addr;
};


/* ext2 file system convention... */
#define	ROOT_INODE_NUMBER	2


extern InodeTable	*get_inode_table( int );
extern void			free_inode_table( InodeTable * );

extern int			get_inode_blocks( char *, InodeTable * );

extern Entry		*get_dir_entry_by_seq( Dentry *, int * );

extern Dentry		*get_file( Dentry *, char * );
extern int			free_file( Dentry * );

extern Dentry		*get_directory( int );
extern int			free_directory( Dentry * );

	
#endif
