/******************************************************************************
 * MyOs	- my special operating system...
 *
 *
 * This is free. If you want to use and fix this program, you can do that...
 *
 * 
 * it's mine only for me...
 *
 * Inhyuk, Kim... kkojiband@hotmail.com
 *
 ******************************************************************************/


#ifndef	__GDT_H__
#define	__GDT_H__


#include "Types.h"


/* 1st descriptor...(0st descriptor is null!) */
#define	KERNEL_CODE		0x8
#define	KERNEL_DATA		0x10

/* 4st descriptor... */
#define	USER_CODE		0x20
#define	USER_DATA		0x28

/* 7st descriptor... */
#define	DEFAULT_LDT		0x38
#define	DEFAULT_TSS		0x40


/* gdt descriptor is 4 bytes... */
typedef struct _gdtDesc		GdtDesc;
struct _gdtDesc
{
	unsigned long	l, h;
};


extern void set_gdt_desc( int, unsigned int, int, int );

/* set task state segment... */
#define	set_tss_desc(num,addr)	set_gdt_desc(num,addr,235,0x89)


#endif
