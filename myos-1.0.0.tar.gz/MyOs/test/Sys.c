#include "Syscall.h"


DECLARE_SYSCALL_0( SYS_EXIT, m_exit );
DECLARE_SYSCALL_0( SYS_FORK, m_fork );
DECLARE_SYSCALL_0( SYS_PAUSE, m_pause );
DECLARE_SYSCALL_2( SYS_OPEN, m_open, const char *, name, int, flags );
DECLARE_SYSCALL_1( SYS_CLOSE, m_close, int, desc );
DECLARE_SYSCALL_3( SYS_READ, m_read, int, desc, char *, buffer, int, size );
DECLARE_SYSCALL_3( SYS_WRITE, m_write, int, desc, const char *, buffer, int, size );
DECLARE_SYSCALL_2( SYS_IOCTL, m_ioctl, int, desc, int, command );
DECLARE_SYSCALL_1( SYS_SLEEP, m_sleep, int, sec );
DECLARE_SYSCALL_1( SYS_USLEEP, m_usleep, int, usec );
DECLARE_SYSCALL_1( SYS_PRIORITY_UP, m_priority_up, int, priority );
