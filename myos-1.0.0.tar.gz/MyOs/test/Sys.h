#ifndef	__WRAPPER_H__
#define	__WRAPPER_H__


extern int	m_exit( void );
extern int	m_fork( void );
extern int	m_pause( void );
extern int	m_open( const char *, int );
extern int	m_close( int );
extern int	m_read( int, char *, int );
extern int	m_write( int, const char *, int );
extern int	m_ioctl( int, int );
extern int	m_sleep( int );
extern int	m_usleep( int );
extern int	m_priority_up( int );


#endif
