#include "Sys.h"


int main( void )
{
	char	buffer[80];
	
	int	i, len;


	m_write( 1, "This is user program-4!\n", 24 );

	for( i = 0; i < 5; i++ )
	{
		len	= m_read( 0, buffer, 80 );

		m_write( 1, "### ", 4 );
		m_write( 1, buffer, len );
	}

	return 0;
}
