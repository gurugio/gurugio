#include <stdio.h>


int main(void)
{
	printf("\nStart Build Utility Programs in utils directory\n\n");
	printf("/* *** */ \n");

	return 0;
}
