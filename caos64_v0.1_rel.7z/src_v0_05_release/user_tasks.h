#ifndef	__USER_TASKS_H__
#define	__USER_TASKS_H__



#define USER1_ADDR		0x40002000
#define USER1_PCB		0x40003000
#define USER2_ADDR		0x40004000
#define USER2_PCB		0x40005000



void user1(void);
	
void user2(void);





#endif
