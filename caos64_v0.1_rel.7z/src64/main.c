

#include <screen.h>
#include <printf.h>

#include <setup.h> // setup_arch()
#include <processor.h> // cli()

#include <types.h>

#include <memory.h> // contig_page_data
#include <page_alloc.h>	// alloc_pages()

#include <slab.h>	// kmem_cache_init(), kmalloc



#include <apic.h>
#include <smp.h>
#include <keyboard.h>


char hello[] = "Hello, CaOS<%d %d %d %d %d %d %d>\n";

char greet[] = "ASMLOVE\n";






void start_kernel(size_t index)
{


	cli();
	


	if (index == 0) {
		init_screen();
		caos_printf("Hello! I am BSP!!\n");
	} else {
		caos_printf("Hello!! I am AP!! I am running??\n");
		while (1) {
			screen_info.video_mem[79]++;

		}
	}

	
	// 6 arguments are stored in register,
	// and others are stored in stack memory.
	// Therefore if there is not type-specifier,
	// compiler cannot know how many byte is valid data in stack.
	// If arguments 6UL, 7UL is 6, 7 without type-specifier,
	// output data is the thrash data from stack with 6 at al or dl register.
	caos_printf("Hello, CaOS. Test printf <%d,%d,%d,%d,%d,%d,%d>\n", 1, 2, 3, 4, 5, 6UL, 7UL);	// variable list

	caos_printf("size int=%d, long=%d, long long=%d\n", sizeof(int), sizeof(long), sizeof(long long));



	//
	// Booting parameters
	// GDT, IDT
	// Paging-Tables
	// memory layout, page management
	//
	setup_arch();





	//
	// setup memory allocator
	//
	kmem_cache_init();




	//
	// device IRQs, timer & keyboard
	//
	//

	keyboard_init();


	/* setup scheduler */


	sti();
//end_kernel:

	while (1) {
	//	screen_info.video_mem[0]++;

	}

}




