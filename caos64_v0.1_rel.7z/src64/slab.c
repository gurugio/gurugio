
#include <slab.h>
#include <printf.h>
#include <bitops.h> // __ffs()
#include <pgtable.h> // PAGE_SIZE
#include <page.h>	// struct page

#include <page_alloc.h> // alloc_pages
#include <string.h>	// memset
#include <types.h>


#define DEBUG 1
#undef DEBUG


struct kmem_cache *cache_cache;
struct page *cache_page;
size_t cache_cache_max;

	






static const char *cache_names[] = {
	"16bytes",
	"32bytes",
	"64bytes",
	"128bytes",
	"256bytes",
	"512bytes",
	"1024bytes"
};



void *kmem_getpages(struct kmem_cache *cachep, flag_t flag)
{

	struct page *page;
	ssize_t i;

	page = alloc_pages(flag, cachep->gfporder);
	if (page == NULL)
		return NULL;


	i = 1 << cachep->gfporder;
	while (i--) {
		__SetPageSlab(&page[i]);

		// slab exists at head of first page
		page[i].slab = page->virtual;
	}



	return (void *)(page->virtual);
}



void kmem_freepages(struct kmem_cache *cachep, void *addr)
{
	size_t i = (1 << cachep->gfporder);
	struct page *page = virt_to_page((u64)addr);


	if (page->private != cachep->gfporder) {
		caos_printf("kmem_freepages fail: page order error\n");
		return;
	}

	while (i--) {
		page->slab = NULL;
		__ClearPageSlab(page++);
	}

	free_pages((u64)addr, cachep->gfporder);

}



void kmem_cache_init(void)
{
	size_t page_size;

	size_t table_size;	
	struct kmem_cache *cp[10];


	page_size = CACHE_CACHE_PAGE;	

	cache_cache_max = (1<<page_size)*PAGE_SIZE/sizeof(struct kmem_cache);


	cache_page = alloc_pages(0, page_size);
	
	
	// linear address of cache_cache table
	cache_cache = cache_page->virtual;


	caos_memset(cache_cache, 0x0, (1<<page_size)*PAGE_SIZE);

	while (page_size--)
		__SetPageSlab(&cache_page[page_size]);


	// default cache descriptors - 16~1024 byte caches
	for (table_size = 0; table_size < sizeof(cache_names)/sizeof(char *); table_size++)
		cp[table_size] = kmem_cache_create(cache_names[table_size], 16*(1<<table_size), 16, 0);


	caos_printf("cache_cache created at <%x>\n", cache_cache);

}





//
// Create a cache
//
// @name: A string to idnetify cache
// @size: The size of objects
// @align: The required alignment for the objects
// @flags: SLAB flags
//
//
struct kmem_cache *kmem_cache_create(const char *name, size_t size, size_t align, flag_t flags)
{
	struct kmem_cache *cachep = cache_cache;
	size_t cache_index;
	size_t page_need, page_order;
	size_t obj_offset;

	size_t obj_num, bufctl_size;


	if (name == NULL || size < BYTES_PER_LONG || size > KMALLOC_MAX_SIZE) {
		caos_printf("FAIL TO CREATE SLAB, <%s>\n", name);
		return NULL;
	}

	cache_index = 0;

	while (cache_cache[cache_index].name != NULL && cache_index < cache_cache_max) {

		if (caos_strcmp(cache_cache[cache_index].name, name) == 0) {
			caos_printf("kmem_cache_create: duplicate cache %s\n", name);
			return NULL;
		}

		cache_index++;

	}

	if (cache_index >= cache_cache_max) {
		caos_printf("kmem_cache_create: cache_cache table is full\n");
		return NULL;
	}


	// new cache is allocated from cache_cache table
	cachep = &cache_cache[cache_index];

#ifdef DEBUG
	caos_printf("index=%d  ", cache_index);
#endif

	// object size must be aligned with processor-word size
	if ((size & (BYTES_PER_LONG-1)) != 0) {
		size += (BYTES_PER_LONG-1);
		size &= ~(BYTES_PER_LONG-1);
	}

	if ((align & (BYTES_PER_LONG-1)) != 0) {
		align += (BYTES_PER_LONG-1);
		align &= ~(BYTES_PER_LONG-1);
	}

	
#ifdef DEBUG
	caos_printf("name:%s size=%d align=%d\n", name, size, align);
#endif


	cachep->name = name;
	cachep->objsize = size;
	cachep->flag = flags;
	INIT_LIST_HEAD(&cachep->slabs);


	// pages for a slabs
	// In slab-page, slab structure and kmem_bufctl_t array and objects are stored.
	page_need = (sizeof(struct slab) + (size * SLAB_DEFAULT_NUM) + (sizeof(kmem_bufctl_t) * SLAB_DEFAULT_NUM) ) / PAGE_SIZE;


	// The argument of __ffs() must be not zero, undefined result is returned.
	if (page_need == 0)
		page_order = 1;
	else
		page_order = __ffs(page_need)+1;

#ifdef DEBUG
	caos_printf("need:%d order=%d ", page_need, page_order);
#endif

	cachep->gfporder = page_order;


	// obj_num objects can be store in slab-pages,
	// but kmem_bufctl_t array occufies space for objects.
	obj_num = ((1<<page_order)*PAGE_SIZE - sizeof(struct slab)) / cachep->objsize;
	bufctl_size = obj_num * sizeof(kmem_bufctl_t);	// size of kmem_bufctl_t array
	obj_num -= (bufctl_size/size + 1);
	cachep->num = obj_num;




	// objs is start at obj_offset in allocated-pages
	// obj_offset is empty space between slab structure and the first objects
	// to align objects.
	obj_offset = sizeof(struct slab) + obj_num*sizeof(kmem_bufctl_t);
	if ( (obj_offset & (align-1)) != 0) {
		obj_offset += (align-1);
		obj_offset &= ~(align-1);
	}

	cachep->colour_off = obj_offset;

#ifdef DEBUG
	caos_printf("cache_num=%d off=%d\n", cachep->num, cachep->colour_off);
#endif

	return cachep;
	
}






//
// Create a slabs for a cache
//
// @cachep: cache that needs slabs
// @flags: SLAB flags
//
//
size_t kmem_cache_grow(struct kmem_cache *cachep, flag_t flags)
{

	struct slab *slabp;
	ssize_t i;

	slabp = (struct slab *)kmem_getpages(cachep, flags);

	if (slabp == NULL)
		return 0;



	// init slab structure
	slabp->inuse = 0;
	slabp->offset = cachep->colour_off;
	slabp->bufctl = (kmem_bufctl_t *)(slabp+1);
	slabp->s_mem = ((u64)slabp + slabp->offset);
	slabp->cache = cachep;

	// bufctl element has index of next free object
	for (i=0; i < cachep->num; i++) {
		(slabp->bufctl)[i] = i+1;
	}
	// signature of last bufctl
	(slabp->bufctl)[i-1] = BUFCTL_END;
	
	// index of the first free object
	slabp->free = 0;

	// add slab into slab-list of cache
	INIT_LIST_HEAD(&slabp->list);
	list_add(&slabp->list, &cachep->slabs);

#ifdef DEBUG
	caos_printf("slabp->%x, offset=%x, free=%x s_mem=%x\n", 
			slabp, slabp->offset, slabp->free, slabp->s_mem);
#endif

	return 1;

}


void kmem_cache_shrink(struct kmem_cache *cachep, flag_t flags)
{
	struct list_head *slabs_list = &(cachep->slabs);
	struct slab *slabp;


	// travel slab-list
	list_for_each_entry(slabp, slabs_list, list) {
#ifdef DEBUG
		caos_printf("slabs=%x\n", slabp);
#endif
	
		// remove one slab at a time
		if (slabp->inuse == 0) {
			slab_destroy(cachep, slabp);
			list_del(&(slabp->list));
			break;
		}
		
	}


	return;
}




void slab_destroy(struct kmem_cache *cachep, struct slab *slabp)
{
	
	// free pages slab is in
	caos_printf("destroy=%x\n", (u64)slabp->s_mem - (u64)slabp->offset);
	kmem_freepages(cachep, (void *)((u64)slabp->s_mem - (u64)slabp->offset));

}





void *caos_kmalloc(size_t size, flag_t flags)
{
	struct kmem_cache *cachep;
	struct slab *slabp;
	struct list_head *slabs_list;
	size_t retry_count = 0;

	size_t cache_index;

	u64 obj;


	cache_index = 0;

	// seek proper cache
	while (cache_cache[cache_index].name != NULL && cache_index < cache_cache_max) {

		if (size <= cache_cache[cache_index].objsize) {
			break;
		}

		cache_index++;

	}


	if (cache_cache[cache_index].name == NULL || cache_index >= cache_cache_max) {
		caos_printf("FAIL TO caos_kmalloc(%d), <no cache>\n", size);
		goto fail_kmalloc;
	}
	
	//caos_printf("cache[%d] ", cache_index);

	cachep = &cache_cache[cache_index];
	slabs_list = &(cachep->slabs);


retry:

	
	if (retry_count > KMALLOC_RETRY_MAX) {
		caos_printf("FAIL TO caos_kmalloc(%d), <kmem_cache_grow fails>\n", size);
		goto fail_kmalloc;
	}


	// travel slab-list, find a slab which has free object
	list_for_each_entry(slabp, slabs_list, list) {
	
		//if ((slabp->bufctl)[slabp->free] != BUFCTL_END) {
		if (slabp->free != BUFCTL_END && slabp->inuse < cachep->num) {
			//caos_printf("slabs=%x\n", slabp);
			break;
		}
	}

	
	// no slab is found, create new slab-pages
	if (slabs_list == &(slabp->list)) {
		kmem_cache_grow(cachep, flags);
		retry_count++;
		goto retry;
	}



	obj = slabp->s_mem + slabp->free * cachep->objsize;

	slabp->inuse++;
	slabp->free = (slabp->bufctl)[slabp->free];


#ifdef DEBUG
	caos_printf("kmalloc: s_mem=%x, inuse=%d/%d obj=%x\n", slabp->s_mem, slabp->inuse, slabp->free, obj);

	do {
		int i;
		caos_printf("bufctl=");
		for(i=0; i<cachep->num;i++) {
			caos_printf("%d ", (slabp->bufctl)[i]);
		}
		caos_printf("\n");

	} while(0);

#endif

	return (void *)obj;



fail_kmalloc:
	return NULL;


}



void caos_kfree(void *objp)
{
	//struct page *slab_pages;
	struct slab *slabp;
	struct kmem_cache *cachep;
	size_t obj_index;

	caos_printf("FREE=%x ", objp);

	//slab_pages = virt_to_page((u64)objp);

	slabp = virt_to_page((u64)objp)->slab;

	if (slabp == NULL) {
		caos_printf("caos_free error: page structure error\n");
		return;
	}


#ifdef DEBUG
	caos_printf("slab->%x \n", slabp);
#endif

	cachep = slabp->cache;
	
	if (cachep == NULL) {
		caos_printf("caos_free error: broken slab\n");
		return;
	}

	if (slabp->inuse <= 0) {
		caos_printf("caos_free error: free non-allocated object\n");
		return;
	}

	obj_index = ((u64)objp - (u64)(slabp->s_mem)) / cachep->objsize;
	(slabp->bufctl)[obj_index] = slabp->free;
	slabp->free = obj_index;
	slabp->inuse--;

#ifdef DEBUG
	caos_printf("slab: objindex=%d inuse=%d, free=%d\n", obj_index, slabp->inuse, slabp->free);

	do {
		int i;
		caos_printf("bufctl=");
		for(i=0; i<cachep->num;i++) {
			caos_printf("%d ", (slabp->bufctl)[i]);
		}
		caos_printf("\n");

	} while(0);
#endif


	// write thrash signature
	caos_memset(objp, 0xa5, cachep->objsize);

}










