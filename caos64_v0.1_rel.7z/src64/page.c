


/*
 *
 * 2008.11.27 - pgd_alloc, pgd_free, pud_alloc, pmd_alloc, pte_alloc_map... Page allocation functions will be added
 *
 */




#include <types.h>
#include <page.h>
#include <setup.h>	// init_mm
#include <pgtable.h> // paging tables

#include <printf.h>

#include <string.h>


#define DEBUG 
#undef DEBUG






//
// Page Global Dir for kernel
//
pgd_t *swapper_pg_dir;


//
// Page descriptor table
//
struct page *mem_map;



// amount of pages for booting-memory allocator
static size_t bootmem_page_index, bootmem_page_start, bootmem_page_max;


void bootmem_init(void)
{
	
	bootmem_page_start = __pa(init_mm.start_heap) >> PAGE_SHIFT;
	bootmem_page_index = bootmem_page_start;
	bootmem_page_max = __pa(init_mm.end_heap) >> PAGE_SHIFT;

	caos_printf("bootmem page %x~%x\n", bootmem_page_index, bootmem_page_max);
}






//
// booting-page allocating, count is page number, not order.
//
void *alloc_bootmem(size_t count)
{

	if (bootmem_page_index+count >= bootmem_page_max) {
		caos_printf("FATAL ERROR: KERNEL HEAP EXHAUSTS");
		halt();
		return NULL;
	}

	bootmem_page_index += count;


	return __va((bootmem_page_index-count) << PAGE_SHIFT);

}




void mem_map_init(void)
{
	unsigned int page_count;

	int mem_map_size;
	int mem_map_page;
	int l;
	u64 virtual_addr;


	page_count = (phy_mem_size * 0x100000)/PAGE_SIZE;
	mem_map_size = page_count * sizeof(struct page) + 11;
	mem_map_page = PAGE_ALIGN(mem_map_size) / PAGE_SIZE;

	caos_printf("page count = %d, mem_map_size = %dbyte, mem_map_page = %d\n", page_count, mem_map_size, mem_map_page);


	// 
	// Mem_map is allocated in kernel-booting memory (kernel heap).
	//
	
	mem_map = (struct page *)alloc_bootmem(mem_map_page);


	caos_printf("mem_map -> %x \n", (unsigned long)mem_map);



	//
	// initialized mem_map table
	//
	virtual_addr = PAGE_OFFSET;
	for (l=0; l<page_count; l++) {
		INIT_LIST_HEAD(&mem_map[l].list);
		mem_map[l].index = l;
		mem_map[l].count = 0;
		mem_map[l].flags = 0;
		mem_map[l].private = -1;
		mem_map[l].virtual = (void *)virtual_addr;
		virtual_addr += 0x1000;
	}


	//
	// set busy pages which are allocated for kernel-booting memory
	// 
	// BIOS booting data : 0x0 ~ 0x1000 (0th page frame)
	// BIOS & ISA video  : 0x9F000 ~ 0x100000
	// kernel image      : 0x100000(0x100th page)~KERNEL_START_STACK
	// kernel heap       : KERNEL_START_STACK ~ bootmem_page_index (page number)
	// 


	//----------------------------------------------------------------
	// for future works...
	// struct resource data-structure must be defined in setup.h
	// and BIOS are will be managed as resource
	// Then busy-page couting will be modified as dynamic counting.
	//----------------------------------------------------------------
	mem_map[0].count = 1;

	for (l=0x9f; l<0x200; l++)
		mem_map[l].count = 1;
	

	for (l=bootmem_page_start; l<bootmem_page_index; l++)
		mem_map[l].count = 1;
	

	
#ifdef DEBUG

	caos_printf("mem_map[%d] : ", mem_map[0].index);
	caos_printf("list.next=%x list.prev=%x ", mem_map[0].list.next, mem_map[0].list.prev);
	caos_printf("count=%d\n", mem_map[0].count);
	caos_printf("mem_map[%d] : ", mem_map[1].index);
	caos_printf("list.next=%x list.prev=%x ", mem_map[1].list.next, mem_map[1].list.prev);
	caos_printf("count=%d\n", mem_map[1].count);
	
	caos_printf("mem_map[%d] ", mem_map[page_count-1].index);
	caos_printf("list.next=%x list.prev=%x ", mem_map[page_count-1].list.next, mem_map[page_count-1].list.prev);
	caos_printf("count=%d\n", mem_map[page_count-1].count);

	caos_printf("Free page start at %x\n",  (u64)alloc_bootmem(1));


#endif



}




//
// phy_mem_size is in MB size
//
void paging_init(size_t phy_mem_size)
{
	size_t l;
	pgd_t *pgd;
	pud_t *pud;
	pmd_t *pmd;
	pte_t *pte;


	pmd_t *pmd_reserv;
	pte_t *pte_reserv;

	
	// 1 PTE covers 2MB (4K * 512)
	// 1 PMD covers 1GB (2MB * 512)
	// 1 PUD covers 512G (1GB * 512)
	// don't care PGD coverage, it's too big??
	size_t pte_count, pmd_count, pud_count, page_count;


	//
	// DIRTY attribute must be set
	//
	u64 page_attr = (_PAGE_DIRTY + _PAGE_ACCESSED + _PAGE_RW + _PAGE_PRESENT);





	pud_count = phy_mem_size / (512 * 1024);
	if (pud_count == 0)
		pud_count = 1;


	pmd_count = phy_mem_size / (1024);
	if (pmd_count == 0)
		pmd_count = 1;

	pte_count = phy_mem_size / 2;
	if (pte_count == 0) {
		caos_printf("FATAL ERROR in PAGING-TABLES BUILDING");
		halt();
		return;
	}

	page_count = phy_mem_size * 256; // 256 pages = 1MB



	// allocate only one PGD
	pgd = (pgd_t *)alloc_bootmem(1);


	// allocate page-tables, each address is linear address.
	pud = (pud_t *)alloc_bootmem(pud_count);
	pmd = (pmd_t *)alloc_bootmem(pmd_count);
	pte = (pte_t *)alloc_bootmem(pte_count);



	// set PGD
	for (l=0; l<0x100; l++)
		set_pgd(pgd+l, __pgd(0));

	set_pgd(pgd+0x100, __pgd(__pa(pud) + page_attr) );

	for (l=0x101; l<0x200; l++)
		set_pgd(pgd+l, __pgd(0));

	
	// set entries in PUD
	for (l = 0; l < pmd_count; l++) {
		set_pud(pud + l, __pud(__pa(pmd + (l*PAGE_SIZE)) +  page_attr) );
	}


	// set entries in PMD
	for (l = 0; l < pte_count; l++) {
		set_pmd(pmd + l, __pmd(__pa(pte) + (l*PAGE_SIZE) +  page_attr) );
	}

	page_attr += (_PAGE_DIRTY);
	// set entries in PTE
	for (l = 0; l < page_count; l++) {
		set_pte(pte + l, __pte(__pa(l*PAGE_SIZE) +  page_attr) );
	}


#ifdef DEBUG
	caos_printf("Init Paging-Table Structure, #%d pud, #%d pmd, #%d pte\n", 
			pud_count, pmd_count, pte_count);
	caos_printf("%x %x %x %x\n", pgd, pud, pmd, pte);
	caos_printf("%d %d %d\n", pud_count, pmd_count, pte_count);
#endif




	//
	// reserve area - APIC, memory-mapped IO devices, BIOS PROM
	//
	// IO APIC: 0xFEC00000 -> linear 0xFFFF8000C0000000
	// Local API: 0xFEE00000 -> linear 0xFFFF8000C0200000
	//
	page_attr = (_PAGE_PRESENT + _PAGE_PCD);

	pmd_reserv = (pmd_t *)alloc_bootmem(1);
	pte_reserv = (pte_t *)alloc_bootmem(10);
	
	set_pud(pud+3, __pud(__pa(pmd_reserv) + page_attr));
	for (l=0; l<10; l++)
		set_pmd(pmd_reserv + l, __pmd(__pa(pte_reserv) + (l*PAGE_SIZE) + page_attr));

	for (l=0; l<512*10; l++)
		set_pte(pte_reserv + l, __pte((0xFEC00000 + l*PAGE_SIZE) + page_attr));


#ifdef DEBUG
	caos_printf("%x %x\n", pmd_reserv, pte_reserv);
#endif

	//
	// CR3 has the physical address of process's PGD
	//
	write_cr3(__pa(pgd));

	__flush_tlb();


	//
	// swapper_pg_dir is PGD of kernel
	//
	swapper_pg_dir = pgd;

	

}






struct page *virt_to_page(u64 vaddr)
{
	size_t pfn = __pa(vaddr) >> PAGE_SHIFT;

#ifdef DEBUG
	caos_printf("virt (%x) to page #(%x)\n", vaddr, pfn);
#endif
	return mem_map+pfn;
}


u64 page_to_virt(struct page *pg)
{
	size_t pfn = pg - mem_map;
#ifdef DEBUG
	caos_printf("page #(%x) to virt (%x)\n", pfn, __va(pfn<<PAGE_SHIFT));
#endif
	return (u64)__va(pfn << PAGE_SHIFT);
}






