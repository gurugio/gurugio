


#include <printf.h>
#include <types.h>
#include <apic.h>
#include <irq_handler.h>
#include <irq_entry.h>	// _ignore_isr
#include <idt.h>	// irq_handler[]
#include <pic8259.h> // ack_pic8259

#define DEBUG
#undef DEBUG


irq_handler_t irq_handler[MAX_IRQ];



void irq_init(void)
{
	ssize_t i;

	for (i = 0; i<MAX_IRQ; i++)
		irq_handler[i] = NULL;


	// INT 0x20~0x2F are reserved for IRQ 0x0~0xF
	// IDT[0x20~0x2F] => irq_handler[0x0~0xF]
	DECLARE_IRQ(0)
	DECLARE_IRQ(1)
	DECLARE_IRQ(2)
	DECLARE_IRQ(3)
	DECLARE_IRQ(4)
	DECLARE_IRQ(5)
	DECLARE_IRQ(6)
	DECLARE_IRQ(7)
	DECLARE_IRQ(8)
	DECLARE_IRQ(9)
	DECLARE_IRQ(10)
	DECLARE_IRQ(11)
	DECLARE_IRQ(12)
	DECLARE_IRQ(13)
	DECLARE_IRQ(14)
	DECLARE_IRQ(15)
	



}

void ignore_isr_handler(void)
{
	caos_printf("Unknown interrupt occur\n");

	end_irq();

}




void register_irq(size_t irq, irq_handler_t handler)
{
	irq_handler[irq] = handler;

#ifdef DEBUG
	caos_printf("HANDLER=%x\n", irq_handler[irq]);
#endif

}



void end_irq(void)
{
	// allow local APIC to queue another interrupt
	ack_APIC_irq();
	ack_pic8259();
}


void handle_irq(size_t irq)
{
	u32 task_pri;
	task_pri = apic_read(APIC_TASKPRI);


	// 0x1f => task priority=1, sub-class=f
	// masing interrupt 0x0~0x1f (processor exceptions)
	apic_write(APIC_TASKPRI, 0x1F);


#ifdef DEBUG
	caos_printf("IRQ[%d] occured.  ", irq);
#endif

	// call irq's own handler
	
	if (irq_handler[irq] != NULL)
		irq_handler[irq]();


#ifdef DEBUG
	caos_printf("end_irq\n");
#endif
	end_irq();
	apic_write(APIC_TASKPRI, task_pri);


}


