

#include <io.h>
#include <pic8259.h>
#include <irq_handler.h>

#include <printf.h>




u16 irq_mask = 0xfffb;

#define	irq_mask0_7	(unsigned char)(irq_mask&0xff)
#define	irq_mask8_15	(unsigned char)((irq_mask>>8)&0xff)


void test_pic(void)
{
	u8 scan;
	scan = inb(0x60);
	caos_printf("TEST_PIC %x\n", scan);
	ack_pic8259();
}


void pic8259_init(void)
{

	
	/* initialize hardware interrupt base vector... */
	outb( 0x20, 0x11 );
	outb( 0xa0, 0x11 );
	
	outb( 0x21, IRQ_VECTOR );
	outb( 0xa1, IRQ_VECTOR+8 );
	
	outb( 0x21, 0x04 );
	outb( 0xa1, 0x02 );
	
	outb( 0x21, 0x01 );
	outb( 0xa1, 0x01 );
	
	outb( 0x21, irq_mask0_7 ); // mask 0~1,3~7 IRQs
	outb( 0xa1, irq_mask8_15 ); // mask 8~15 IRQs


	// test for external irq from PIC8259
	//register_irq(1, test_pic);
	//enable_pic8259(0x1);

}


/*
 * enable specified IRQ by store mask bit.
 */
void enable_pic8259(size_t irq)
{
	irq_mask	= irq_mask & ~(1<<irq);

	if( irq >= 8 )
		outb( 0xa1, irq_mask8_15 );
	else
		outb( 0x21, irq_mask0_7 );
}

/*
 * disable specified irq by set mask bit
 */
void disable_pic8259(size_t irq)
{
	irq_mask	= irq_mask | (1<<irq);

	if( irq >= 8 )
		outb( 0xa1, irq_mask8_15 );
	else
		outb( 0x21, irq_mask0_7 );
}


void ack_pic8259(void)
{
	outb(0x20, 0x20);	// EOI
}




