#include <apic.h>




//
//  clock estimation will be implemented later..
//  This delay does just delay-loop
//
static void delay(size_t count)
{
	volatile s64 a = -1;

	for (; count > 0; count--) {
		for (; a > 0; a--)
			continue;
	}


}



void wake_ap(void)
{

	// send Startup IPIs to AP
	// refer to INTEL PROCESSOR MANUAL vol.2 & MP specification
	
	apic_write(APIC_ICR, 0xc4500);
	delay(1000000);
	delay(1000000);

	apic_write(APIC_ICR, 0xc4609);
	delay(1000000);


	apic_write(APIC_ICR, 0xc4609);
	delay(1000000);

}



size_t cpu_id(void)
{

	return apic_read(APIC_ID);
}
