
// 
// all functions are copy of linux/arch/x86_64/kernel/apic.c
// refer to include/asm-x86_64/apic.h, apicdef.h
//
//

#include <processor.h>
#include <apic.h>

#include <pgtable.h>
#include <irq_handler.h>

#include <screen.h> // screen_info


#define DEBUG
#undef DEBUG


u8 x86_cpu_to_apicid[NR_CPUS] = { [0 ... NR_CPUS-1] = 0xff };









ssize_t verify_local_APIC(void)
{
	u32 reg0, reg1;

	reg0 = apic_read(APIC_LVR);

#ifdef DEBUG
	caos_printf("local apic version=%x\n", reg0);
#endif

	apic_write(APIC_LVR, reg0^APIC_LVR_MASK);
	reg1 = apic_read(APIC_LVR);
#ifdef DEBUG
	caos_printf("local apic version=%x\n", reg1);
#endif
	


	return 1;
}


void bsp_local_timer(void)
{

	static u8 tick=0;
	ssize_t i;

	for (i=79; i>=0; i--)
		set_screen(i, ' ');


	set_screen(0, 'B');
	set_screen(1, 'S');
	set_screen(2, 'P');
	set_screen(3, tick++);
	

	set_screen(77, 'A');
	set_screen(78, 'P');

	ack_APIC_irq();

}


void init_bsp_timer(void)
{
	u32 lvt_timer;


	//
	// Timer interrupt period is hard-coding value.
	// Dynamic analysis of processor's bus clock is need.
	//

	apic_write(APIC_TMICT, 0xFFFFFF);

	apic_write(APIC_TDCR, APIC_TDR_DIV_32);


	lvt_timer = apic_read(APIC_LVTT);

	lvt_timer &= (~APIC_LVT_MASKED);
	lvt_timer |= APIC_LVT_TIMER_PERIODIC;
	lvt_timer |= LOCAL_TIMER_VECTOR;	// vector = 0x20
	apic_write(APIC_LVTT, lvt_timer);

#ifdef DEBUG
	caos_printf("APIC_LVTT=%x\n", lvt_timer);
#endif
	
	if ((apic_read(APIC_LVTT) & APIC_LVT_MASKED) == 0)
		caos_printf("Local timer of CPU #%d is enabled\n", apic_read(APIC_ID));
		


	// timer irq -> IRQ 0x0 -> INT 0x20
	register_irq(0, bsp_local_timer);


}






void init_local_apic(void)
{

	u32 lapic_SVR;
	u32 lapic_id;

	u32 reg;


	lapic_id = apic_read(APIC_ID);

	caos_printf("Init local apic ID=%d...", lapic_id);

	verify_local_APIC();



	// init BSP's local APIC
	lapic_SVR = apic_read(APIC_SPIV);
	lapic_SVR |= APIC_SPIV_APIC_ENABLED;
	apic_write(APIC_SPIV, lapic_SVR);

	lapic_SVR = apic_read(APIC_SPIV);
	if (lapic_SVR & APIC_SPIV_APIC_ENABLED)
		caos_printf("enabled\n");


	apic_write(APIC_TASKPRI, 0x1f); // mask 0~0x1f (reserved for exceptions)
	//apic_write(APIC_TASKPRI, 0); // accept all INT

	// mask all local int
	apic_write(APIC_LVTT, 0x10000); // disable local timer
	apic_write(APIC_LVTTHMR, 0x10000);	
	apic_write(APIC_LVTPC, 0x10000);	
	
	
	apic_write(APIC_LVT1, 0x10000);	
	//apic_write(APIC_LVT0, 0x10000);	

	//apic_write(APIC_LVT1, 0x400);		// LINT1 as NMI
	//apic_write(APIC_LVT0, 0x4721);	// enable LINT0 as ExtINT
	
	reg = apic_read(APIC_LVT0);
	reg &= APIC_LVT_MASKED;
	reg |= APIC_LVT_LEVEL_TRIGGER;
	reg |= APIC_INPUT_POLARITY;
	reg |= 0x700;

	apic_write(APIC_LVT0, reg);

	
	//apic_write(APIC_LVT0, 0x2700);	// enable LINT0 as ExtINT
	
	apic_write(APIC_LVTERR, 0x10000);	
	// spurious interrupt vector = 0x2F
	apic_write(APIC_SPIV, apic_read(APIC_SPIV) | 0x2f);


#ifdef DEBUG
	caos_printf("SPIV=%x", apic_read(APIC_SPIV));
	caos_printf("LINT0=%x\n", apic_read(0x350));
	caos_printf("LINT1=%x", apic_read(0x360));
	caos_printf("error=%x\n", apic_read(0x370));
	caos_printf("perfor=%x", apic_read(0x340));
	caos_printf("therm=%x\n", apic_read(0x330));
#endif



}


