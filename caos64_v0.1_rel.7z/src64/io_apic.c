


//
// IO APIC setting is under constructing.
// 
// WARNING! Never use this file till it's completed.
//


#include <io_apic.h>





void io_apic_init(void)
{
	ssize_t entry, i;

	u64 tbl;
	
	caos_printf("IO APIC ID=%x\n", (io_apic_read(0x0)>>24) & 0xF);


	caos_printf("IO APIC VER=%x ", GET_IO_APIC_VERSION(io_apic_read(IO_APIC_VERSION)) );
	caos_printf("IO APIC Entry=%d\n", (GET_IO_APIC_ENTRY(io_apic_read(0x1))) );

	entry = GET_IO_APIC_ENTRY(io_apic_read(IO_APIC_VERSION));
	
	for (i = 0; i <= entry; i++) {
		//io_apic_write(IO_APIC_REDTBL_BASE + i*2, IO_APIC_IRQ_MASK);


		tbl = io_apic_read(IO_APIC_REDTBL_BASE + i*2);
		//tbl |= ((u64)(0xFF)<<56); // all processors
		tbl &= ~IO_APIC_IRQ_MASK;  // unmask
		tbl &= ~IO_APIC_TRIG_MODE; // edge
		tbl &= ~IO_APIC_INTPOL; // high active
		tbl |= IO_APIC_DESTMOD;	// loginal mode + set of processors
		tbl |= IO_APIC_DELMOD_ExtINT;	// ExtINT

		tbl |= 0x21+i;	// vector

		io_apic_write(IO_APIC_REDTBL_BASE + i*2, tbl);

	}


}


