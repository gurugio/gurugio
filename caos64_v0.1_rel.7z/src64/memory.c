
#include <types.h>
#include <memory.h>
#include <page.h>

#include <list.h>	// struct list_head
#include <printf.h>



#define DEBUG 1


#define ONE_MB (1024*1024)

static char *zone_names[MAX_NR_ZONES] = {"NORMAL"};


// x86 has only one node
pg_data_t contig_page_data;




void count_pages(size_t *free)
{
	struct list_head *head = &contig_page_data.node_mem_map[0].list;
	struct page *pg;


	
	*free = 0;

	list_for_each_entry(pg, head, list) {
		if (pg->count == 0)
			(*free)++;
	}

#ifdef DEBUG
	caos_printf("free pages = %d  ", *free);

	struct page *tmp = NULL;
	head = &contig_page_data.node_mem_map[0].list;

	list_for_each_entry(pg, head, list) {
		if (pg->count != 0) {
			caos_printf("busy page idx=%x ~ ", pg->index);
			tmp = pg;
			break;
		}
	}


	list_for_each_entry(pg, &tmp->list, list) {
		if (pg->count != 1) {
			caos_printf("%x\n", pg->index-1);
			tmp = pg;
			break;
		}
	}
#endif

}



void memory_init(size_t phy_mem_size)
{
	struct zone *z;
	size_t l;

	//
	// page-list initliazation
	//
	contig_page_data.nr_zones = MAX_NR_ZONES;
	contig_page_data.node_mem_map = mem_map;
	contig_page_data.node_start_paddr = 0;
	contig_page_data.node_size = phy_mem_size*ONE_MB;

	// nodes are for NUMA & SMP system.
	// These are reserved for future.
	contig_page_data.node_id = 0;
	contig_page_data.node_next = NULL;	// only node


	z = &contig_page_data.node_zones[ZONE_NORMAL];

	//
	// zone initliazation
	//
	z->size = contig_page_data.node_size;
	z->zone_pgdat = &contig_page_data;
	z->zone_start_paddr = contig_page_data.node_start_paddr;
	z->name = zone_names[ZONE_NORMAL];

	z->pages = contig_page_data.node_size / PAGE_SIZE; 

	z->zone_start_pfn = 0;	// every pages are in this zone
	z->zone_mem_map = &mem_map[contig_page_data.node_zones[ZONE_NORMAL].zone_start_pfn];

	//
	// Pages in the same zone is linked together
	//
	for (l=z->zone_start_pfn; l<z->pages; l++) {
		list_add_tail(&mem_map[l].list, &(z->zone_mem_map->list) );
		mem_map[l].page_zone = z;

		if (mem_map[l].count != 0) {
			mem_map[l].private = -1;
		}
	}

	// set number of free pages
	count_pages(&z->free_pages);


#ifdef DEBUG
	caos_printf("zone[%s] size=%d, mem_map=%x, free=%d\n",
			z->name, z->size, z->zone_mem_map, z->free_pages);
#endif



}




