
#ifndef __SMP_H__
#define __SMP_H__








void wake_ap(void);
size_t cpu_id(void);






#endif


