
/********************************************************************
 * DESCRIPTION : I do not know what these function do exactly.
 *               I just copy it from several source.
 *               I hate hardware programming, 
 *               but I have studied how hardware work for 2 years
 *               to make my own OS. It is so difficult to me. ;-)
 *               The most important thing is I cannot write any
 *               description this file. :-(
 * FILE NAME : IRQ.h
 *******************************************************************/
#ifndef __IRQ_HANDLER_H__

#define __IRQ_HANDLER_H__

#include <types.h>
#include <idt.h>

#define MAX_IRQ 16
#define IRQ_VECTOR 0x20

typedef void (*irq_handler_t)(void);



#define DECLARE_IRQ(num)	\
	extern void _irq_##num(void);	\
	set_intr_gate(IRQ_VECTOR+num, _irq_##num);


void irq_init(void);
void ignore_isr_handler(void);

extern irq_handler_t irq_handler[MAX_IRQ];





void handle_irq(size_t);
void end_irq(void);

void register_irq(size_t, irq_handler_t);

#endif
