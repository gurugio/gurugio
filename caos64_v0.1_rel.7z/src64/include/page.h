
#ifndef	__PAGE_H__
#define	__PAGE_H__


#include <list.h>
#include <pgtable.h>
#include <types.h>

#include <bitops.h>
#include <page-flags.h>




/* mem_mep_t presents a page frame */
struct page {
	struct list_head list;
	size_t private;	// for buddy system
	size_t index;
	size_t count;
	flag_t flags;
	void * virtual;	// virtual address the page is mapped

	struct zone *page_zone;

	void *slab;
};


extern struct page *mem_map;

void bootmem_init(void);
void *alloc_bootmem(size_t);


void paging_init(size_t);
void mem_map_init(void);

struct page *virt_to_page(u64 vaddr);
u64 page_to_virt(struct page *);




#endif
