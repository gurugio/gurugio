#ifndef __IRQ_ENTRY_H__
#define __IRQ_ENTRY_H__




extern void _ignore_isr(void);
extern void _irq_0(void);
extern void _irq_1(void);






#endif
