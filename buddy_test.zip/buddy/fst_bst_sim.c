#include <stdio.h>
#include <fcntl.h>
#include <limits.h>
#include <string.h>
#include <stdlib.h>

/****************************************************/
/*  Definitions                                                                          */
#define FIRSTFIT 111           // first-fit policy
#define BESTFIT 222                    // best-fit policy
#define FREELIST 11                   // free-block list
#define BUSYLIST 22           // busy-block list

#define NUM 10000                      // number of requesting blocks

//#define DEBUG
// ������ ���ø�
typedef struct _block_tag{
        unsigned int uiStartAddress;             // start point of block
        unsigned int uiBlockSize;                // size of block
        unsigned long ulBlockNumber;           // same with process number
        unsigned int uiRunTime;                 // How long block will be in memory?
        struct _block_tag *ptrPrev;                       // doubly linked list pointers
        struct _block_tag *ptrNext;
} block_t;

/*******************************************/
/* global variables                        */
block_t * FreeListHead;                          // header of free-block list
block_t * BusyListHead;                         // header of busy-block list
unsigned int TOTALMEMORY;                  // Total initial memory
unsigned long RefBlockNumber;                  // number of requested block.
//unsigned int gs_uiTotalFreeMem;                       // How much memory is free?

int iAllocTime[NUM];                                    // The time when next block will request.
int iDeallocTime[NUM];                          // How long each block will be in memory
// average of requested memory size.
int iMemSize1000[NUM];
int iMemSize2000[NUM];
int iMemSize3000[NUM];
int iMemSize4000[NUM];
int iMemSize5000[NUM];



/*********************************************/

int InitList(void);
void AddList(block_t *, block_t *);
void DelList(block_t *);
void PrintList(block_t *);
int DeallocBlock(block_t *);
block_t *AllocBlock(unsigned int, int);
int SimulateFirstFit(void);
int SetGlobalData(char *, int *);



/**********************************************************
 * FUNCTION NAME : Simulate
 * SYNOPSIS : Simulate each memory-allocation policy.
 * EXTERNAL EFFECTS : RefBlockNumber, TOTALMEMORY,
 * ARGUMENTS : int A_iPolicy (memory allocation policy),
                              int *A_ptrMemSize (array of requested memory size)
 * RETURN :
 * ERRNO :
 **********************************************************/
int Simulate(const int A_iPolicy, const int *A_ptrMemSize)
{
        // variables for Internal fragmentation.
        unsigned long ulTotalRequestMem = 0;
        unsigned long ulTotalAllocMem = 0;
        // variables for External fragmentation.
        long double ulExternFrag = 0;
        unsigned long ulTotalFreeMem = TOTALMEMORY;
        // variables for Allocation failure ratio.
        unsigned long ulAllocFailNum = 0;
        unsigned long ulTotalRequestNum = 0;
        // How long run the simulation?
        unsigned long ulSimulTime = 0;

		int FlagSucess = 0;
		int Loop = 0;
		int i = 0;

        //int flagAlloc = 1;
        block_t *temp, *temp2;

        InitList();

        // increase simulation-time per one loop.
        for (;;ulSimulTime++)
        {
                /*   ������ ������ŭ��(10000��) ������ �Ҵ��Ѵ�.   */
                if (RefBlockNumber < NUM)
                {
						

                        // ���� �Ҵ��� �������� ��쿡�� External-fragmentation��
                        // Allocation failure ratio�� ����Ѵ�.
                        if (AllocBlock(A_ptrMemSize[RefBlockNumber], A_iPolicy) == 0) {
								Loop = 1;
                                // 1. External Fragment
                                // �� ������ �޸��� ũ�⸦  ���� ������� �޸��� ũ���  ���� ���������Ѵ�.
                                ulExternFrag += ((float)TOTALMEMORY/(TOTALMEMORY-ulTotalFreeMem));
                                // 2. Allocation Failure Ratio
                                // �Ҵ��� ��� �����ϴ� ���� ī��Ʈ�Ѵ�.
                                ulAllocFailNum++;
								FlagSucess = 0;

                        // ���� �Ҵ��� ������������ Internal fragmentation�� �����Ѵ�.
                        } else {
								Loop = iAllocTime[RefBlockNumber];//FlagSucess = 1;
#ifdef DEBUG
                                printf("###allocate Block #%d\n\n", RefBlockNumber);
                                PrintList(FreeListHead);
                                PrintList(BusyListHead);
#endif
                                ulTotalFreeMem -= A_ptrMemSize[RefBlockNumber];
                                // 1. Internal fragmentation
                                // ��û�� �޸��� ũ��� ���� ������� �޸��� ũ�⸦ ���� �����Ѵ�.
                                ulTotalRequestMem += A_ptrMemSize[RefBlockNumber];
                                ulTotalAllocMem += (TOTALMEMORY - ulTotalFreeMem);
                                // ���� ��û���� �Ѿ��.
                                RefBlockNumber++;
                        }
                        // Allocation failure ratio
                        // �� ����� ��û�� �߻��ϴ°��� ī��Ʈ�Ѵ�.
                        ulTotalRequestNum++;
                }

                /*   �ð��� ������ �Ҵ�� �������� �������ش�.   */
                /* ������� �޸� ������ ����Ʈ�� ���鼭 ������ ���� �ð��� �˻��ؼ�
                   �ð��� �ٵ� �޸� ������ �������ְ� �ƴ� ������ �ð��� �������ش�.   */

				
				i = 0;
				for (i = 0; i < Loop; i++) {
					temp = BusyListHead->ptrNext;
					while (temp != NULL) {
						if (temp->uiRunTime == 0) {
#ifdef DEBUG
                                printf("###deallocate block #%d\n", temp->ulBlockNumber);
#endif

                                ulTotalFreeMem += temp->uiBlockSize;
                                temp2 = temp;
                                temp = temp->ptrNext;
                                // �ð��� �� ���� ������ ����.
                                DeallocBlock(temp2);
#ifdef DEBUG
                                PrintList(FreeListHead);
                                PrintList(BusyListHead);
#endif
                        } else {
                                // �ð��� ���� ������ ���� �ð��� �����Ѵ�.
                                temp->uiRunTime--;
                                temp = temp->ptrNext;
                        }
						ulSimulTime++;
	                }
				}
				

                // ��� ������ �Ҵ�Ǿ��ٰ� �ٽ� ��� �����Ǿ����� �ù����̼��� ������.
                if (RefBlockNumber >= 9998 && BusyListHead->ptrNext == NULL)
                        break;

        }
        // 1. �� �ù����̼� �ð�
        fprintf(stdout, "Simulation time : %ld\n", ulSimulTime);
        // 2. Internal Fragmentation
        fprintf(stdout, "Internal Fragmentation : %f\n",
                        (float)ulTotalAllocMem/(float)ulTotalRequestMem);
        // 3. External Fragmentation
        if (ulAllocFailNum != 0)
                fprintf(stdout, "External Fragmentation : %f\n",
                                (float)ulExternFrag/ulAllocFailNum);
        else
                fprintf(stdout, "External Fragmentation : There is not allocation failure at all.\n");

        // 4. Allocation Failure Ratio
        if (ulAllocFailNum != 0)
                fprintf(stdout, "Allocation Failure Ratio : %f\n",
                                (float)ulAllocFailNum/ulTotalRequestNum);
        else
                fprintf(stdout, "Allocation Failure Ratio : There is not allocation failureat all.\n");
        fprintf(stdout, "\n\n");
        return 1;
}

/**********************************************************
 * FUNCTION NAME : SetGlobalData
 * SYNOPSIS : Read data files and write array to read data.
 * EXTERNAL EFFECTS :
 * ARGUMENTS : char *A_ptrFileName (The name of data file to read)
 *                                   int *A_ptrData (The pointer of array to write data)
 * RETURN :
 * ERRNO : -1 (fail to read file)
 **********************************************************/
int SetGlobalData(char *A_strFileName, int *A_ptrData)
{
        char buffer[10];
        int i = 0;
        FILE *fd;
        if ((fd = fopen(A_strFileName, "r")) == NULL) {
                perror("fopen(A_strFileName) in SetGlobalData");
                return -1;
        }
        // ������ ���پ� ���� ���� ������ ��ȯ�ؼ� �迭�� �����Ѵ�.
        while (fgets(buffer, 10, fd) != NULL) {
                buffer[strlen(buffer) - 1] = '\0';
                A_ptrData[i] = atoi(buffer);
                i++;
        }
        return 1;
}



/**********************************************************
 * FUNCTION NAME : CheckList
 * SYNOPSIS : Is there a block I want process?
 * EXTERNAL EFFECTS : FreeListHead, BusyListHead
 * ARGUMENTS : block_t *A_ptrBlock (pointer of block to check)
 *             int A_iFlag (Which list do you want check?)
 * RETURN : 1 (There is a block I want process)
 * ERRNO : fatal error -> terminate program.
 *         if I process a block do not be included in list,
 *         unidentified error occur!
 **********************************************************/
int CheckList(block_t *A_ptrBlock, int A_iFlag)
{
        block_t *temp;
        if (A_iFlag == FREELIST)
                temp = FreeListHead;
        else if (A_iFlag == BUSYLIST)
                temp = BusyListHead;
        while (1) {
                if (temp == NULL)
                        break;
                if (temp == A_ptrBlock)
                        return 1;
                temp = temp->ptrNext;
        }
        fprintf(stderr, "FATAL ERROR : This Block (%x) is not in the linked list\n", A_ptrBlock);
        exit(1);
}
/**********************************************************
 * FUNCTION NAME : AllocBlock
 * SYNOPSIS : Check free block list and allocate free memory
 *            amount of I request.
 * EXTERNAL EFFECTS : FreeListHead, RefBlockNumber
 *                    iDeallocTime[]
 * ARGUMENTS : unsigned int A_uiRequestSize (memory block size)
 *             int A_iFlag (flag to indentify FIRST_FIR / BEST_FIT)
 * RETURN : temp (Allocated block pointer)
 * ERRNO : NULL (There is no enough memory to allocate)
 **********************************************************/
block_t *AllocBlock(unsigned int A_uiRequestSize, int A_iFlag)
{
        block_t *temp;
        block_t *newBlock;
        block_t *reservBlock;
        unsigned int DefSize = UINT_MAX;

        temp = FreeListHead->ptrNext;

        /**************************************************
         * first-fit policy
         * free-list�� �˻��ϸ鼭 ��û�� ���� ������� ū ���� ������
         * ������ �ٷ� �޸𸮸� �Ҵ����ش�.
         ***************************************************/
        if (A_iFlag == FIRSTFIT)
        {
                while (temp != NULL)
                {
                        // If size of the free-block is equal to requested size,
                        // remove it from free-list to busy-list.
                        if (temp->uiBlockSize == A_uiRequestSize) {
                                DelList(temp);
                                temp->ulBlockNumber = RefBlockNumber;
                                temp->uiRunTime = iDeallocTime[RefBlockNumber];
                                AddList(BusyListHead, temp);
                                return temp;
                        }
                        // If size of the free-block is larger than requested size,
                        // substract size of the free-block by requested size,
                        // and make another block to insert to busy-list.
                        else if (temp->uiBlockSize > A_uiRequestSize) {
                                // make a block to insert.
                                newBlock = (block_t *)malloc(sizeof(block_t));
                                if (newBlock == NULL) {  // system error
                                        perror("(in AllocBlock) malloc(newBlock) fail");
                                        exit(1);
                                }

                                newBlock->uiStartAddress = temp->uiStartAddress;
                                newBlock->uiBlockSize = A_uiRequestSize;
                                newBlock->ulBlockNumber = RefBlockNumber;
                                newBlock->uiRunTime = iDeallocTime[RefBlockNumber];
                                // substract block size.
                                temp->uiBlockSize -= A_uiRequestSize;
                                temp->uiStartAddress += A_uiRequestSize;

                                AddList(BusyListHead, newBlock);
                                return newBlock;
                        }
                        temp = temp->ptrNext;
                }
#ifdef DEBUG
                fprintf(stdout, "error: There is no memory more.\n");
#endif
                // fail to allocate.
                return NULL;

        /**************************************************
         * best-fit policy
         * free-list�� �˻��ϸ鼭 ��û�� ���� ������� ũ�Ⱑ ���� �����
         * ������ ã�Ƽ� �޸𸮸� �Ҵ����ش�.
         ***************************************************/
        } else if (A_iFlag == BESTFIT) {
                while (temp != NULL)
                {
                        if (temp->uiBlockSize > A_uiRequestSize) {
                                // ��û�� ũ��� ���� ���̰� ���� ������ �����͸� ����Ѵ�.
                                if ( (temp->uiBlockSize - A_uiRequestSize) < DefSize) {
                                        DefSize = temp->uiBlockSize - A_uiRequestSize;
                                        reservBlock = temp;
                                }
                        }
                        temp = temp->ptrNext;
                }
                // ��û�� ũ�⺸�� ũ�ų� ���� ���� �޸��� ������ ����.
                if (DefSize == UINT_MAX) {
#ifdef DEBUG
                        fprintf(stderr, "error: There is no memory more.\n");
#endif
                        return NULL;
                }

                if (reservBlock->uiBlockSize == A_uiRequestSize) {
                                DelList(reservBlock);
                                reservBlock->ulBlockNumber = RefBlockNumber;
                                reservBlock->uiRunTime = iDeallocTime[RefBlockNumber];
                                AddList(BusyListHead, reservBlock);
                                return reservBlock;
                }
                else if (reservBlock->uiBlockSize > A_uiRequestSize) {
                                newBlock = (block_t *)malloc(sizeof(block_t));
                                if (newBlock == NULL) {  // system error
                                        perror("(in AllocBlock) malloc(newBlock) fail");
                                        exit(1);
                                }

                                newBlock->uiStartAddress = reservBlock->uiStartAddress;
                                newBlock->uiBlockSize = A_uiRequestSize;
                                newBlock->ulBlockNumber = RefBlockNumber;
                                newBlock->uiRunTime = iDeallocTime[RefBlockNumber];
                                reservBlock->uiBlockSize -= A_uiRequestSize;
                                reservBlock->uiStartAddress += A_uiRequestSize;

                                AddList(BusyListHead, newBlock);
                                return newBlock;
                        }
        } //     } else if (A_iFlag == BESTFIT) {
        else
        {
                printf("please give a flag to simulate");
                exit(1);
        }
        fprintf(stderr, "fatal error in AllocBlock()\n");
        exit(1);
}


/**********************************************************
 * FUNCTION NAME : DeallocBlock
 * SYNOPSIS : Deallocate memory block, move block from busy list
 *            to free list, then merge block with near block.
 * EXTERNAL EFFECTS : FreeListHead, BusyListHead
 *                    iDeallocTime[]
 * ARGUMENTS : block_t *A_ptrBlock (block to deallocate)
 * RETURN : 1 (success to deallocate)
 * ERRNO : -1 (fail to deallocate)
 **********************************************************/
int DeallocBlock(block_t *A_ptrBlock)
{
        block_t *temp;
        unsigned int BlockStart, BlockEnd;
        unsigned int FreeStart, FreeEnd;
        CheckList(A_ptrBlock, BUSYLIST);
        temp = FreeListHead->ptrNext;

		if (temp == NULL) {
			DelList(A_ptrBlock);
			AddList(FreeListHead, A_ptrBlock);
			return 1;
		}

        // ������ ������ ���� �ּҿ� ���ּ� ���.
        BlockStart = A_ptrBlock -> uiStartAddress;
        BlockEnd = (A_ptrBlock -> uiStartAddress + A_ptrBlock -> uiBlockSize);

        // ����Ʈ�� ������ �˻��غ���.
        while (temp != NULL) {
                // ����� �ٷ� �ڷ� ������ �����Ҷ�
                if (temp->ptrPrev == FreeListHead && BlockStart < temp->uiStartAddress) {
                        DelList(A_ptrBlock);
                        if (temp->uiStartAddress == BlockEnd) {
                                temp->uiStartAddress = BlockStart;
                                temp->uiBlockSize += A_ptrBlock->uiBlockSize;
                                free(A_ptrBlock);
                        } else {
                                //DelList(A_ptrBlock);
                                AddList(temp->ptrPrev, A_ptrBlock);
                        }
                        return 1;
                }

                // ������ ����� �ٷ� �ڷ� �����Ҷ�
                if (temp->ptrNext == NULL){
                        DelList(A_ptrBlock);
                        // ������ ��庸�� ������ �����Ҷ�
                        if (temp -> uiStartAddress > BlockStart) {
                                // ������ ���� ����� ���۰� ������ ���κ��� ��ġ
                                if (BlockEnd == temp->uiStartAddress) {
                                        temp->uiStartAddress = BlockStart;
                                        temp->uiBlockSize += A_ptrBlock->uiBlockSize;
                                        free(A_ptrBlock);
                                }
                                else {
                                        AddList(temp->ptrPrev, A_ptrBlock);
                                }
                        // ������ ����� �ڷ� ����
                        } else if (temp->uiStartAddress < BlockStart) {
                                // ����� ���� ������ ������ ��ġ��
                                if (temp->uiStartAddress + temp->uiBlockSize == BlockStart) {
                                        temp->uiBlockSize += A_ptrBlock->uiBlockSize;
                                        free(A_ptrBlock);
                                }else
                                        AddList(temp, A_ptrBlock);
                        }
                        return 1;
                }// end of  "if (temp->ptrNext == NULL) {"

                FreeEnd = temp -> uiStartAddress + temp -> uiBlockSize;
                FreeStart = (temp -> ptrNext) -> uiStartAddress;
                // ���� ����Ʈ�� �� ���� ���̿� ����
                if ( (temp->uiStartAddress < BlockStart) &&
                        (temp->ptrNext->uiStartAddress > BlockStart)) {
                        DelList(A_ptrBlock);

                        // 1. ������ �� ���� ���� ���̿� �ִ�.
                        if (BlockStart == FreeEnd && BlockEnd == FreeStart) {
                                temp->ptrNext->uiStartAddress = temp->uiStartAddress;
                                temp->ptrNext->uiBlockSize     +=     (A_ptrBlock->uiBlockSize     + 
temp->uiBlockSize);
                                DelList(temp);
                                free(temp);
                                free(A_ptrBlock);

                        // 2. ������ ������ ���� ������ ���� ����.
                        } else if (BlockStart == FreeEnd) {
                                // ���� ������ ũ�Ⱑ Ŀ����.
                                temp->uiBlockSize += A_ptrBlock->uiBlockSize;
                                free(A_ptrBlock);
                        // 3. ������ ���� ���� ���� ������ ���۰� ����.
                        } else if (BlockEnd == FreeStart) {
                                // ���� ������ ���� �ּҰ� ��������.
                                temp->ptrNext->uiStartAddress = A_ptrBlock->uiStartAddress;
                                temp->ptrNext->uiBlockSize    =     temp->ptrNext->uiBlockSize    + 
A_ptrBlock->uiBlockSize;
                                free(A_ptrBlock);

                        // 4. �ּҰ� �̾����� ������ ����.
                        } else {
                                AddList(temp, A_ptrBlock);
                        }
                        return 1;
                }
                temp = temp->ptrNext;
        }// end of while()

        return -1;
}

/**********************************************************
 * FUNCTION NAME : InitList
 * SYNOPSIS : Initialize header of Free/Busy linked list,
 *            and set total free memory in 16K.
 *            and initialize global data from file.
 * EXTERNAL EFFECTS : FreeListHead, BusyListHead
 *                    ulTotalFreeMem
 * ARGUMENTS :
 * RETURN : 1 (success to initialize)
 * ERRNO : -1 (fail to allocate memory for header block)
 **********************************************************/
int InitList(void)
{
        block_t *temp;
        /*   make header of free-block list   */
        if ((FreeListHead = (block_t *)malloc(sizeof(block_t))) == NULL) {
                perror("malloc(FreeListHead) in Initlist()");
                return -1;
        }
        FreeListHead->uiStartAddress = UINT_MAX;
        FreeListHead->uiBlockSize = UINT_MAX;
        FreeListHead->ulBlockNumber = UINT_MAX;
        FreeListHead->ptrPrev = NULL;
        FreeListHead->ptrNext = NULL;

        /*   make header of busy-block list   */
        if ((BusyListHead = (block_t *)malloc(sizeof(block_t))) == NULL){
                perror("malloc(BusyListHead) in InitList()");
                return -1;
        }

        RefBlockNumber = 0;

        /*   make initial block of free-block   */
        if ((temp = (block_t *)malloc(sizeof(block_t))) != NULL) {
				temp -> ulBlockNumber = 0;
                temp -> uiStartAddress = 0;
                temp -> uiBlockSize = TOTALMEMORY;
                AddList(FreeListHead, temp);
        } else {
                perror("malloc(temp) in InitFreeList()");
                return -1;
        }

        BusyListHead->uiStartAddress = UINT_MAX;
        BusyListHead->uiBlockSize = UINT_MAX;
        BusyListHead->ulBlockNumber = UINT_MAX;
        BusyListHead->ptrPrev = NULL;
        BusyListHead->ptrNext = NULL;

        // data of interval of allocation.
        SetGlobalData("alloc_time_10.dat", iAllocTime);
        // data of how long the block exist in memory.
        SetGlobalData("dealloc_time_100.dat", iDeallocTime);
        // data of average size of requested memory block
		SetGlobalData("mem_size_1000.dat", iMemSize1000);
		SetGlobalData("mem_size_2000.dat", iMemSize2000);
		SetGlobalData("mem_size_3000.dat", iMemSize3000);
		SetGlobalData("mem_size_4000.dat", iMemSize4000);
		SetGlobalData("mem_size_5000.dat", iMemSize5000);


        return 1;
}


/**********************************************************
 * FUNCTION NAME : AddList
 * SYNOPSIS : Add block to any list.
 *            First argument is a block already in list
 *            and second argument is a block to insert list
 *            at next of given in first augument
 * EXTERNAL EFFECTS :
 * ARGUMENTS : block_t *A_ptrAhead (I insert a block at next of
 *                                  this block)
 *             block_t *A_ptrBlock (block to insert)
 * RETURN :
 * ERRNO :
 **********************************************************/
void AddList(block_t *A_ptrAhead, block_t *A_ptrBlock)
{
        if (A_ptrAhead -> ptrNext != NULL) {
                A_ptrBlock -> ptrNext = A_ptrAhead -> ptrNext;
                A_ptrBlock -> ptrPrev = A_ptrAhead;
                (A_ptrAhead -> ptrNext) -> ptrPrev = A_ptrBlock;
                A_ptrAhead -> ptrNext = A_ptrBlock;
        } else {
                A_ptrBlock -> ptrPrev = A_ptrAhead;
                A_ptrAhead -> ptrNext = A_ptrBlock;
                A_ptrBlock -> ptrNext = NULL;
        }
}

/**********************************************************
 * FUNCTION NAME : DelList
 * SYNOPSIS : Delete a block from list, not free a block.
 * EXTERNAL EFFECTS :
 * ARGUMENTS : block_t *A_ptrBlock (A block to delete)
 * RETURN :
 * ERRNO :
 **********************************************************/
void DelList(block_t *A_ptrBlock)
{
        if (A_ptrBlock -> ptrNext == NULL)
                (A_ptrBlock -> ptrPrev) -> ptrNext = NULL;
        else {
                (A_ptrBlock -> ptrNext) -> ptrPrev = A_ptrBlock -> ptrPrev;
                (A_ptrBlock -> ptrPrev) -> ptrNext = A_ptrBlock -> ptrNext;
        }
}

/**********************************************************
 * FUNCTION NAME :
 * SYNOPSIS :
 * EXTERNAL EFFECTS :
 * ARGUMENTS :
 * RETURN :
 * ERRNO :
 **********************************************************/
void PrintList(block_t *A_ptrStart)
{
        block_t *temp = A_ptrStart;
        if (A_ptrStart == FreeListHead)
                printf("Free Block List...\n");
        else
                printf("Busy Block List...\n");

        while (temp != NULL) {
#ifdef DEBUG
                printf("%x ", temp);
#endif
                printf("BlockNumber : %5ld StartAddress : %6ld BlockSize : %6ld\n",
                                temp -> ulBlockNumber,
                                temp -> uiStartAddress,
                                temp -> uiBlockSize);
                temp = temp -> ptrNext;
        }
        printf("\n");
}

/**********************************************************
 * FUNCTION NAME :
 * SYNOPSIS :
 * EXTERNAL EFFECTS :
 * ARGUMENTS :
 * RETURN :
 * ERRNO :
 **********************************************************/
int main(void)
{

	
	TOTALMEMORY = 16384;
	printf("##############################\n");
	printf("     < FIRST FIT POLICY >");
	printf("     (Total Memory Size : %7d)\n", TOTALMEMORY);
	printf("##############################\n\n");

	

	printf("1. Average requested memory size is 1000....\n");
	Simulate(FIRSTFIT, iMemSize1000);

	printf("2. Average requested memory size is 2000....\n");
	Simulate(FIRSTFIT, iMemSize2000);


	printf("3. Average requested memory size is 3000....\n");
	Simulate(FIRSTFIT, iMemSize3000);

			
	printf("4. Average requested memory size is 4000....\n");
	Simulate(FIRSTFIT, iMemSize4000);


	printf("5. Average requested memory size is 5000....\n");
	Simulate(FIRSTFIT, iMemSize5000);


	printf("##############################\n");
	printf("     < BEST FIT POLICY >");
	printf("     (Total Memory Size : %7d)\n", TOTALMEMORY);
	printf("##############################\n\n");

	printf("1. Average requested memory size is 1000....\n");
	Simulate(BESTFIT, iMemSize1000);
	printf("2. Average requested memory size is 2000....\n");
	Simulate(BESTFIT, iMemSize2000);
	printf("3. Average requested memory size is 3000....\n");
	Simulate(BESTFIT, iMemSize3000);
	printf("4. Average requested memory size is 4000....\n");
	Simulate(BESTFIT, iMemSize4000);
	printf("5. Average requested memory size is 5000....\n");
	Simulate(BESTFIT, iMemSize5000);

        return 0;
}
