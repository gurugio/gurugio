#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "buddy.h"


#define total_pages (16)
#define PAGE_SIZE 4096


page_t *expand(zone_t *, page_t *, unsigned int, \
				unsigned int, unsigned int, free_area_t *);


void init_zone(zone_t *, char *, unsigned int, unsigned int);
void init_mem_map(zone_t *, unsigned int, unsigned int);
void print_free_list(zone_t *);
void init_free_list(zone_t *);
void set_page_count(page_t *, int, unsigned int);
page_t *rmqueue(zone_t *, unsigned int);






page_t *mem_map;
zone_t zone;


UCHAR bitmap_0[1024];
UCHAR bitmap_1[512];
UCHAR bitmap_2[256];
UCHAR bitmap_3[128];
UCHAR bitmap_4[64];
UCHAR bitmap_5[32];
UCHAR bitmap_6[16];
UCHAR bitmap_7[8];
UCHAR bitmap_8[4];
UCHAR bitmap_9[2];

char zone_name[] = "CaOS";

/* Because there can be several zone, 
 * init_zone function must have argument as attribute of the zone. */
void init_zone(zone_t *zone, char *name, unsigned int pages_num, unsigned int page_index)
{
		int i;
		
		zone->name = name;
		zone->size = pages_num;
		zone->free_pages = pages_num;
		zone->pages_min = (unsigned int)(pages_num / 100);
		
		for (i = 0; i < 10; i++)
				INIT_LIST_HEAD(&((zone->free_area[i]).free_list));

		(zone->free_area[0]).map = bitmap_0;
		(zone->free_area[1]).map = bitmap_1;
		(zone->free_area[2]).map = bitmap_2;
		(zone->free_area[3]).map = bitmap_3;
		(zone->free_area[4]).map = bitmap_4;
		(zone->free_area[5]).map = bitmap_5;
		(zone->free_area[6]).map = bitmap_6;
		(zone->free_area[7]).map = bitmap_7;
		(zone->free_area[8]).map = bitmap_8;
		(zone->free_area[9]).map = bitmap_9;


		zone->zone_mem_map = mem_map+page_index;
		zone->zone_start_paddr = page_index * PAGE_SIZE;
		zone->zone_start_mapnr = page_index;

}


/* there can be several zones. 
 * Therefore i give argument zone. */
void init_mem_map(zone_t *zone, unsigned int start, unsigned int size)
{
		page_t *p;
		unsigned int i=0;

		for (p = mem_map+start; p < mem_map + size; p++) {
				p->count = i++;
				INIT_LIST_HEAD(&(p->list));
				p->zone = zone;
				p->flag = 0x0;
		}
		
}


void print_free_list(zone_t *zone)
{
		unsigned int order = 0;
		free_area_t *area;
		page_t *page;
		list_head *head, *curr;

		area = &(zone->free_area[order]);

		printf("\n---------free_list------------\n");
		do {
				head = &(area->free_list);
				curr = head->next;

				printf("free_list[%d] : ", order);
				while (curr != head) {
						page = list_entry(curr, page_t, list);
						printf("%d~%d ", page - mem_map, (int)(page-mem_map)+((1<<order)-1));
						curr = curr->next;
				}
				printf("\n");
				
				area++;
				order++;
		} while (order < MAX_ORDER);
		printf("------------------------------\n\n");

}


/* There can be several zones, 
 * therefore there can be several free list in the system */
void init_free_list(zone_t *zone)
{
		
		page_t *p = zone->zone_mem_map;
		free_area_t *area = &(zone->free_area[MAX_ORDER-1]);
		unsigned int size = 1 << (MAX_ORDER-1);
		unsigned int list_count;
		list_head *list;
		unsigned int pages_num = zone->free_pages;
		
		while (size > 0) {
				list = &(area->free_list);
				list_count = pages_num / size;
				pages_num -= (list_count * size);

				for (; list_count > 0; list_count--) {
						__list_add(&(p->list), list->prev, list);
						p += size;
				}
		
				size >>= 1;
				area--;
		}


		area = &(zone->free_area[9]);
		list = &(area->free_list);

}


void set_page_count(page_t *page, int count, unsigned int order)
{
		unsigned int i;
		
		for (i = 0; i < (1 << order); i++)
				(page++)->count = count;
}


page_t *expand(zone_t *zone, page_t *page, unsigned int index, \
				unsigned int low_order, unsigned int high_order, free_area_t *area)
{
		unsigned int size = 1 << high_order;

		while (high_order > low_order) {
				area--;
				high_order--;
				size >>= 1;

				list_add(&(page->list), &(area->free_list));

				MARK_USED(index, high_order, area);

				index += size;
				page += size;
		}
		return page;
}


page_t *rmqueue(zone_t *zone, unsigned int order)
{
		free_area_t *area;
		unsigned int curr_order = order;
		page_t *page;
		list_head *head, *curr;
		unsigned int index;

		area = &(zone->free_area[order]);

		do {
				head = &(area->free_list);
				curr = head->next;

				if (curr != head) {

						page = list_entry(curr, page_t, list);

						list_del(curr);

						index = page - zone->zone_mem_map;
						if (curr_order != MAX_ORDER-1)
								MARK_USED(index, curr_order, area);

						zone->free_pages -= (1UL << order);
						printf("## FIND pages at order(%d)\n", curr_order);
						page = expand(zone, page, index, order, curr_order, area);

						set_page_count(page, 1, order);
						printf("## ALLOCATED page index : (%d)\n", page-mem_map);
						return page;
				}
				curr_order++;
				area++;
		} while (curr_order < MAX_ORDER);

		return NULL;
}

page_t *alloc_pages(zone_t *zone, unsigned int gfp_mask, unsigned int order)
{
		unsigned long min;
		page_t *page;

		min = (1UL << order) + zone->pages_min;
	
		printf("## REQUEST pages order(%d)\n", order);
		if (zone->free_pages > min+zone->pages_min) {
				printf("## DO alloc_page from (%s)\n", zone->name);
				page = rmqueue(zone, order);
				if (page != NULL)
						return page;
		}

		if ( (gfp_mask & __GFP_WAIT) == 1) {
				min -= (zone->pages_min>>2);
				if (zone->free_pages > min) {
						printf("## DO alloc_page from (%s)\n", zone->name);
						page = rmqueue(zone, order);
						if (page != NULL)
								return page;
				}
		}

		printf("## FAIL to allocate (%d) pages\n", (1 << order));
		return NULL;
}




void free_pages(page_t *page, unsigned int order)
{
		unsigned int index, page_index, mask;
		free_area_t *area;
		page_t *base;
		zone_t *zone;
		page_t *buddy1, *buddy2;


		/*    -x = ~x + 1 
		 * => ~x = -x - 1
		 * Therefore (~0) << order = (-0 - 1) << order = - (1 << order)
		 * -mask = (1 << order) => size of freed pages
		 */
		mask = (~0UL) << order;
		zone = page->zone;
		base = zone->zone_mem_map;
		page_index = page - base;
		
		if (page_index & ~mask) {
				printf("## align error\n");
				return;
		}
		
		printf("## FREE page (%d~%d)\n", page-mem_map, page-mem_map+(1<<order)-1);
		set_page_count(page, 0, order);
		page->flag &= ~((1 << PG_referenced) | (1 << PG_dirty));

		index = page_index >> (1 + order);
		area = zone->free_area + order;
		
		zone->free_pages -= mask;

		/* -mask = 1 + ~mask
		 *       =          */
		while (mask + (1 << (MAX_ORDER-1))) {
				if (__get_bit(index, (void *)area->map) == 0) {
						printf("end merge\n");
						break;
				}
				buddy1 = base + (page_index ^ -mask);
				buddy2 = base + page_index;
				printf("## buddy1 : %d, buddy2 : %d => MERGE! \n", buddy1-base, buddy2-base);
				list_del(&(buddy1->list));
				printf("## list_del(%d) from order(%d)\n", buddy1-base, area-zone->free_area);
				mask <<= 1;
				area++;
				index >>= 1;
				/* 'page_index' always indicate the first page of the buddy */
				page_index &= mask;
		}

		/* base->page_index == buddy1 */
		/* If order is 9, variable buddy1 is not computed,
		 * so base->page_index is used */
		list_add(&(base + page_index)->list, &(area->free_list));
		printf("## list_add(%d) from order(%d)\n", (base+page_index)-base, area-zone->free_area);

}
				

		
		

/* TO DO LIST :
 * set flag of page descriptors?
 * init bitmap
 */

int main(void)
{

		page_t *page1, *page2, *page3, *page4;
		//int a = 0;


		mem_map = malloc(total_pages*sizeof(page_t));
		
		init_mem_map(&zone, 0, total_pages);
		init_zone(&zone, zone_name, total_pages, 0);
		init_free_list(&zone);

		print_free_list(&zone);

		page1 = alloc_pages(&zone, 0, 2);
		print_free_list(&zone);
		printf("return page : %d\n", page1-mem_map);
	
		page2 = alloc_pages(&zone, 0, 0);
		print_free_list(&zone);
		printf("return page : %d\n", page2-mem_map);
		
		page3 = alloc_pages(&zone, 0, 1);
		print_free_list(&zone);
		printf("return page : %d\n", page3-mem_map);
		
		/*page4 = alloc_pages(&zone, 0, 6);
		print_free_list(&zone);
		printf("return page : %d\n", page4-mem_map);*/


		/*free_pages(page4, 6);
		print_free_list(&zone);

		free_pages(page3, 6);
		print_free_list(&zone);

		free_pages(page2, 7);
		print_free_list(&zone);

		free_pages(page1, 8);
		print_free_list(&zone);*/

		return 0;
}




