

void __change_bit(unsigned int, void *);
unsigned char __test_and_change_bit(unsigned int, void *);
unsigned char __get_bit(unsigned int, void *);
void __set_bit(unsigned int , void *);
void __clear_bit(unsigned int , void *);


#define MARK_USED(index, order, area) \
				__change_bit((index) >> (1+(order)), (area)->map);

		


