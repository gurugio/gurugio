#include <stdio.h>


int main(void)
{

		int i = 0;
		



		return 0;
}
