
		
/* These macros are written by inline assembly code in Linux kernel,
 * but I write this macro with C lanuage for portability */

/*
 * toggle bit
 * index : page descriptor index
 * order : order of bitmap
 * area : 
 */
void __change_bit(unsigned int index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		/* toggle */
		if ( (*p & (1 << bit)) != 0)  /* if 1 */
				*p &= ~(1 << bit);        /* clear */
		else                          /* if 0 */
				*p |= (1 << bit);         /* set */
}

/* If the bit is 1, return 1 and clear
 * else the bit is 0, return 0 and set */
unsigned char __test_and_change_bit(unsigned int index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		/* bit is 1 */
		if ( (*p & (1 << bit)) != 0) {
				*p &= ~(1 << bit);  /* clear */
				return 1;
		/* bit is 0 */
		} else {
				*p |= (1 << bit);  /* set */
				return 0;
		}
}

unsigned char  __get_bit(unsigned int index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		return *p & (1 << bit);
}


void __set_bit(unsigned int index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		*p |= (1 << bit);
}


void __clear_bit(unsigned int index, void *addr)
{
		unsigned int byte = index/8;
		int bit = 7 - (index%8);
		char *p = (char *)addr + byte;

		*p &= ~(1 << bit);
}




