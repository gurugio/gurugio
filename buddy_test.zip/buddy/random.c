/*********************************************************************
	Random Number Generation by using Uniform Distribution
*********************************************************************/

/***** Header Files *****/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
//#include <conio.h>

/***** Macros *****/
#define TOTAL_GEN_NUM 10000		/* The number of random numbers to be generated */
#define MAX_MEAN 10000			/* Maximum value of Mean Value */
#define INTER_NUM 1000			/* For calculating the Kai Square value */

/***** Grobal Variables *****/
long int Expec[INTER_NUM];		/* Expectation value */
long int interval[INTER_NUM];
double kai_squ;					/* Kai Square vale */
long int mean_value;			/* Mean value of the random numbers */
double real_mean;
int real_inter_num;

/***** Function Prototype *****/
void Init_Val(void);
void User_Input(void);
void Rand_Num_Gen(void);
void Kai_Squ_Fun(void);
int Continue_Or_Not(void);
void Print_Fun(void);


/***** Main Function *****/
int main(void)
{
	int stop;

	User_Input();

	do {
		Init_Val();

		Rand_Num_Gen();
		Kai_Squ_Fun();

		printf("\nTry again (Y/N)? ");
		stop = Continue_Or_Not();
		printf("\n\n\n");
	} while (stop);

	printf("Generated random numbers store in file 'RNG.txt'.\n\n");

	return 0;
}


/***** Function Declaration *****/
void User_Input(void)
{
	int stop;

	do {
		printf("\n\n********* Random Number Generation Program *********\n");
		printf("The more smaller Kai Square Value, the more good..^^\n");
		printf("\nWhat is the Mean value of the random numbers(10, 50, 100, etc.)? : ");
		scanf("%ld", &mean_value);
		getchar();

		if ((mean_value <= 0) || (mean_value > MAX_MEAN)) {
			printf("\nIncorrect mean value... Continue (Y/N)? ");
			stop = Continue_Or_Not();
		}
		else 
			stop = 0;
	} while (stop);

	printf("\nMean value is %ld.\n", mean_value);
}

void Init_Val(void)
{
	int i;

	real_inter_num = (mean_value-1)/2;

	for (i=0; i<INTER_NUM; i++){
		interval[i] = 0;
	}

	for (i=0; i<INTER_NUM; i++) {
			Expec[i] = ((TOTAL_GEN_NUM) / (real_inter_num));
	}
	
	real_mean = 0.0;
}

void Rand_Num_Gen(void)
{
	int i, j;
	long int z_t, max_value;
	double temp, gap;
	FILE *data_fp;

	max_value = (2 * (mean_value-1));
	gap = (double)(max_value) / real_inter_num;
//	printf("gap = %f\n", gap);
	real_mean = 0.0;

	data_fp = fopen("RNG.txt", "w");

	srand((unsigned)time(NULL));
	for (i=0; i<TOTAL_GEN_NUM; i++) {
		temp = ((double)rand()) / (RAND_MAX) * (max_value);

		z_t = (int)(temp + 0.5);
		fprintf(data_fp, "%ld\n", (z_t + 1));

		real_mean += (double)z_t;

		j=0;
		while (z_t > ((j+1) * gap)) {
			j++;
		}
		interval[j]++;
	}

	real_mean = real_mean / TOTAL_GEN_NUM;

	fclose(data_fp);
}

void Kai_Squ_Fun(void)
{
	int i;

	kai_squ=0;
	for (i=0; i<real_inter_num; i++) {
		kai_squ += (((double)(interval[i]) - Expec[i]) * ((double)(interval[i]) - Expec[i]) / Expec[i]);
	}

	printf("Kai Square Value      = %f\n", kai_squ);
	printf("Calculated Mean Value = %f\n", real_mean);

//	Print_Fun();
}

int Continue_Or_Not(void)
{
	char cont;

	scanf("%c", &cont);
	getchar();
	if ((cont == 'Y') || (cont == 'y'))
		return(1);
	else
		return(0);		
}

void Print_Fun(void)
{
	int i;

	printf("\ninterval[] \t Expec[]\n");
	for (i=0; i<real_inter_num; i++) {
		printf("%8ld \t %6ld\n", (long int)interval[i], (long int)Expec[i]);
	}
}
