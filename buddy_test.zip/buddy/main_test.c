#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "buddy.h"





#define TEST_COUNT 10000
#define DATA_COUNT 10000

typedef struct active_list {
		list_head list;
		int time_count;
		page_t *page;
		int order;
		int index;
} active_list_t;



int next_time[DATA_COUNT];
int resident_time[DATA_COUNT];
list_head active_head;

unsigned int global_time;


unsigned int add_counter;
unsigned int del_counter;
unsigned int fail_counter;
double fail_ratio;



int read_file(char *filename, int *array)
{
        char buffer[5];
        int i = 0;
        FILE *fd;
        if ((fd = fopen(filename, "r")) == NULL) {
                perror("fopen()");
                return -1;
        }
        while (fgets(buffer, 5, fd) != NULL) {
                buffer[strlen(buffer) - 1] = '\0';
                array[i] = atoi(buffer);
                i++;
        }
				fclose(fd);
        return 0;
}


void init_test(void)
{
		read_file("resident.dat", resident_time);
		read_file("next.dat", next_time);
		INIT_LIST_HEAD(&active_head);	
		global_time = 0;
		
		add_counter = 0;
		del_counter = 0;
		fail_counter = 0;
		fail_ratio = 0;
		
}


void add_active(page_t *page, int time, int order, int index)
{
		active_list_t *entry;

		entry = (active_list_t *)malloc(sizeof(active_list_t));

		entry->time_count = time;
		entry->page = page;
		entry->order = order;
		entry->index = index;

		list_add(&(entry->list), &active_head);
		add_counter++;

}


void del_active(active_list_t *entry)
{
		list_del(&(entry->list));
		free(entry);
		del_counter++;
}


void take_time(void)
{
		list_head *curr = &active_head;
		active_list_t *entry;
		

//		printf("TIME : %d\n", global_time++);
		
		curr = curr->next;
		while (curr != &active_head) {
				entry = list_entry(curr, active_list_t, list);
				entry->time_count--;
				curr = curr->next;
				
				if (entry->time_count == 0) {
//						printf("DEL : index <%5d>\n", entry->index);
						free_pages(entry->page, entry->order);
						del_active(entry);
				}
				
		}
}


				

int main(void)
{
		int i;
		int order[TEST_COUNT];
		page_t *page[TEST_COUNT];
		
		//list_head *curr = &active_head;
		//active_list_t *entry;
		
		unsigned int next_index = 0;
		
		init_test();
		init_buddy();
		
		srand((unsigned)time(NULL));
		print_free_list(&zone);

		for (i = 0; i < TEST_COUNT; i++) {
				order[i] = (rand() % MAX_ORDER);
				//printf("order[%d] = %d\n", i, order[i]);
		}
		/*order[0] = 5;
		order[1] = 1;
		order[2] = 7;
		order[3] = 3;
		order[4] = 4;
		order[5] = 9;
		order[6] = 5;
		order[7] = 7;
		order[8] = 3;
		order[9] = 2;*/

	

		while (next_index < TEST_COUNT) {
				next_time[next_index]--;
				take_time();
				if (next_time[next_index] <= 0) {
						page[next_index] = alloc_pages(&zone, 0, order[next_index]);
						
						if (page[next_index] != NULL) {
								add_active(page[next_index], resident_time[next_index], 
												order[next_index], next_index);
//								printf("ADD : index <%5d>   time <%3d>\n", 
//												next_index, resident_time[next_index]);
//								print_free_list(&zone);
						} else {
								printf("ALLOCATION FAIL # %d\n", fail_counter);
								printf("free pages / total system pages : %d / %d = %f\n", 
												(int)zone.free_pages, total_pages,
												(double)zone.free_pages/(double)total_pages);
								printf("# of requesting pages : %d\n", 1 << order[next_index]);
								fail_counter++;
								fail_ratio += ((double)zone.free_pages/(double)total_pages);
						}						
						
						next_index++;
				}
		}

		while (active_head.next != &active_head) {
				take_time();
		}
		print_free_list(&zone);

		printf("ADD COUNTER : %d\n", add_counter);
		printf("DEL COUNTER : %d\n", del_counter);
		printf("FAIL COUNTER : %d\n", fail_counter);
		printf("FAIL RATIO : %f\n", fail_ratio/(double)fail_counter);
		
		return 0;
}



